import sys,os
import argparse
import subprocess

def find_path(input_file, DCid_column, save_file, addition_dir = False):
	input = [x.rstrip().split('\t') for x in open(input_file)]
	tmp = []
	DC_path = ['/data5/DC_results/Result_new3', '/data5/DC_results/Result_new2', '/data1/DC_results/Result_new', '/data5/DC_results/Result_new', '/data2/DC_results/Result_new', '/data3/DC_results/Result_new', '/data6/DC_results/Result_encode3/', '/data6/DC_results/Result_2016_ATAC', '/data6/DC_results/Result_2016_k27ac', '/data6/DC_results/Result_2016All', '/data5/DC_results/Result_2016All2', '/data6/DC_results/Result_2018Collect', '/data6/DC_results/DC_new']
	if addition_dir:
		DC_path = DC_path+addition_dir.split(',')
	for line in input:
		id, n = line[int(DCid_column)], 1
		print id
		for p in DC_path:
			list = None
			path = os.path.join(p, 'dataset%s'%id)
			if not os.path.exists(path):
				path = os.path.join(p, id)
			if not os.path.exists(path):
				path = os.path.join(p, 'dataset_%s'%id)
			if os.path.exists(path):
				list = line + [path]
				tmp.append(list)
				break
			else:
				continue
			if (n == len(DC_path)-1) and (not list):
				list = line + ['NA']
				tmp.append(list)
			n = n+1
					
	out = open(save_file, 'w')
	for x in tmp:
		print >>out, '\t'.join(x)
	out.close()	

def main():

	# start = time.time()

	try:
		parser = argparse.ArgumentParser(description="""find DC result path""")
		parser.add_argument( '-i', dest='inputfile_path', type=str, required=True, help='raw data file which contains DCID' )
		parser.add_argument( '-c', dest='DCID_column', type=str, required=True, help='DCID column' )
		parser.add_argument( '-s', dest='save_path', type=str, required=True, help='the file name where would like to save to')
		parser.add_argument( '-a', dest='add_path', type=str, required=False, help='additional directory, split with ,')

		
		args = parser.parse_args()
		
		if args.add_path:
			find_path(args.inputfile_path, args.DCID_column, args.save_path, args.add_path)
		else:
			find_path(args.inputfile_path, args.DCID_column, args.save_path)

		
	except KeyboardInterrupt:
		sys.stderr.write("User interrupted me!\n")
		sys.exit(0)
		
if __name__ == '__main__':
	main()
