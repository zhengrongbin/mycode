import sys
f = sys.argv[1]

import os
import django
import cPickle as p
  ## mkvirtualenv dc2, and pip install -r requirements.txt
sys.path.append('/data/home/qqin/01_Projects/Programming/dc2/lib/python2.7/site-packages')
sys.path.append('/data/home/qqin/01_Projects/Programming/dc2')
sys.path.append('/data/home/qqin/01_Projects/Programming/dc2/dc2')
sys.path.append('/data/home/qqin/01_Projects/Programming/dc2/datacollection')
sys.path = sys.path[::-1]
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "dc2.settings")
django.setup()
from datacollection import models
#from pubmed import getOrCreatePaper
import pubmed
dat = [x.rstrip().split('\t') for x in open(f)]
for iterm in dat:
	gsm = iterm[1]
	ppmid = iterm[-1]
	sample = models.Samples.objects.filter(unique_id = gsm)[0]
#	print 'sample.paper: %s'%(sample.paper)
	if (not sample.paper) and ppmid != 'NA':
		print gsm
		#paper = pubmed.getOrCreatePaper(ppmid)
	#	print paper
		sample.paper = pubmed.getOrCreatePaper(ppmid)
		sample.save()
	elif sample.paper and (str(sample.paper.pmid) != ppmid) and (ppmid != 'NA'):
		print gsm
		#paper = pubmed.getOrCreatePaper(ppmid)
	#	print paper
		sample.paper = pubmed.getOrCreatePaper(ppmid)
		sample.save()
	else:
		continue


