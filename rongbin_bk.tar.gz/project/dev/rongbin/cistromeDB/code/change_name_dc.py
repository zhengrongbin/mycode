import os,sys
import argparse
from optparse import OptionParser
"""this code is for chnanging name of ChiLin result. eg: the result data folder is dataset_GSM123456, we want to change to dataset_1234,
    1234 here usually is DCid in our mysql database.
"""


import os
def getlist(fdir,orig,substr):
    filist=[]
    listdir=[]
    try:
        tmp=os.listdir(fdir)
        tmp=[os.path.join(fdir,i) for i in tmp]  
        for i in tmp:
            if os.path.isfile(i):
                filist.append(i)
            if os.path.isdir(i):
                listdir.append(i)  
        while len(listdir)>0:
            a=[]
            for j in listdir:
                tmp=os.listdir(j)
            tmp=[os.path.join(j,i) for i in tmp]
            for i in tmp:
#                print i
                if i.endswith('seqpos') or i.endswith('fastqc'):
                    filist.append(i)
                else:
        			d=1
        			if os.path.isfile(i):
        				filist.append(i)
        			if os.path.isdir(i):
        				a.append(i) 			
            listdir=a
    except:
        print fdir
        return None,None
        # 	print listdir
    #orig=filist[0].split('/')[-1].split('_')[1]
    #filist2=[i.replace(orig,substr) for i in filist]
    filist2 = []
    for i in filist:
    	base = i.replace(fdir, '').replace(orig, substr).lstrip('/')
    	filist2.append(os.path.join(fdir, base))
    newdir = os.path.join('/'.join(fdir.split('/')[:-1]), 'dataset%s'%substr)
    filist.append(fdir)
    filist2.append(newdir)
    return filist,filist2


def _excute(fpath, oldid_col, newid_col, dir_col):
    out = open('change_name_cmd.sh', 'w')
    for iterm in [x.rstrip("\n").split("\t") for x in open(fpath)]:
    	if iterm[int(dir_col)] in ['NA', 'None', 'none']:
    		print iterm[int(oldid_col)]
    		continue
    	a,b=getlist(iterm[int(dir_col)], iterm[int(oldid_col)], iterm[int(newid_col)])
    	if b == None:
    		continue
    	for i in range(len(a)):
    		cmd = 'mv %s %s'%(a[i],b[i])
    		#os.system(cmd)
    		print >>out, cmd
    out.close()

def main():
    try:
        parser = argparse.ArgumentParser(description="""change name of ChiLin results, cater to the general pattern of cistrome DC, eg: dataset_1234""")
        parser.add_argument('-f', dest='fpath', type=str, required = True, help='The file contain original id, new id, and datapath.')
        parser.add_argument('-old', dest='oldid_col', type=str, required = True, help='column of original id in the file, start with 0.')
        parser.add_argument('-new', dest='newid_col', type=str, required = True, help='column of new id in the file, start with 0.')
        parser.add_argument('-dir', dest='dir_col', type=str, required = True, help='column of the path of ChiLin result in the file, start with 0.')
        args = parser.parse_args()
        _excute(args.fpath, args.oldid_col, args.newid_col, args.dir_col)
    except KeyboardInterrupt:
        sys.stderr.write("User interrupted me!\n")
        sys.exit(0)

if __name__ == '__main__':
    main()


