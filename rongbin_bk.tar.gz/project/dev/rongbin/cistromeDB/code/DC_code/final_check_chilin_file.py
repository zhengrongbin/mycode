import sys,os
import argparse

def add_filepath(dirpath,topath, cmd=None):
#"""add columns information about path of pdf, xls, peak, bam files and json"""
	get=[]
	f=[dirpath]
	for i in f:
		path=dirpath
		if path and os.path.isdir(path):
			i = [i]
			dataset = os.listdir(path)	
			peak=[i1 for i1 in dataset if i1.endswith('sort_peaks.narrowPeak.bed') or i1.endswith('sort_peaks.broadPeak.bed') and i1.find('rep') == -1]
			if peak:
				path_peak = os.path.join(path, ''.join(peak))
				i.append(path_peak)
			else:
				i.append('NA')

			xls=[i1 for i1 in dataset if i1.endswith('peaks.xls') and i1.find('rep') == -1]
			if xls:
				path_xls = os.path.join(path, ''.join(xls))
				i.append(path_xls)
			else:
				i.append('NA')
			p_attic = os.path.join(path, 'attic')
			if 'attic' in dataset and os.path.isdir(p_attic):
				attic = os.listdir(p_attic)
				if 'json' in attic and os.path.isdir(os.path.join(p_attic, 'json')):
					path_json = os.path.join(p_attic, 'json')
					i.append(path_json)
				else:
					i.append('NA')			
				treat=[i1 for i1 in attic if i1.endswith('bam') and i1.find('treat') != -1]
				if treat and len(treat) >= 1:
					path_bam = os.path.join(p_attic, ''.join(treat))
					i.append(path_bam)
#				elif treat and len(treat) > 1:
#					treatment = [i2 for i2 in treat if i2.find('treatment') != -1]
#					if treatment:
#						path_bam = os.path.join(p_attic, ''.join(treatment))
#						i.append(path_bam)
#					else:
#						i.append('NA treatment.bam')
				else:
					i.append('NA')
			else:
				i.append('NA')
		else:
			i.append('NA')
	get.append(i)
	for x in get:
		l=[]
		for i in x:
			if i == "NA":
				l.append('a')
		if not l:
			print( '%s files checked OK'%dirpath)
			if os.path.isdir(topath):
				os.system('mv %s %s'%(dirpath,topath))
			else:
				print ('destination path is not exists,please check')	
		else:
			print ('%s files checked failed'%dirpath)
			if cmd is not None:
#				print ('%s files checked failed'%dirpath)
				os.system("rm -r %s"%dirpath)
				os.system('nohup chilin run -c  %s.conf &'%dirpath)
#			print cmd

def main():
	try:
		parser = argparse.ArgumentParser(description="""check chilin result and rerun if error happened""")
		parser.add_argument( '-d', dest='dirpath', type=str, required=True, help='dictory path need to check,separate by comma if a list')
		parser.add_argument('-p',metavar='topath',type=str,required=True,help='dictory path the successful sample  will move to')
		parser.add_argument( '-c', action ='store_true', help='ChiLin command for rerun')
		args = parser.parse_args()
		word = args.dirpath.strip().split(',')
		for line in word:
			if args.c is not None:
				add_filepath(line,args.p, args.c)
			else:
				add_filepath(line,args.p)

	except KeyboardInterrupt:
		sys.stderr.write("User interrupted me!\n")
		sys.exit(0)

if __name__ == '__main__':
	main()
	
