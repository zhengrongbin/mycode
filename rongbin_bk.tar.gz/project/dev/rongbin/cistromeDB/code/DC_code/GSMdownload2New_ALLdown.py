#!/usr/bin/env python
#Author     : shenglin mei
#Name       :
#Description:
#Usage      :
#------------------------------
import os,sys,re

fin = sys.argv[1]
fout = sys.argv[2]
#fs = sys.argv[3]
#fe = sys.argv[4]
tmp_path=sys.argv[3]
des_path=sys.argv[4]



#fs = int(fs)-1
#fe =int(fe)-1

from subprocess import call

fph = open(fin)
content = fph.readlines()#[fs:fe]#[3110:3210]# 1200:1250 110: 150   #phrase1 0:50  51:140 198:500 501:700
i=1
for line in content:
    print i
    i = i +1
    line2 = line.strip('\n').split('\t')
#    line2= line[1:]
    print line2[15],line2[17],line2,line2[15].split(','),line2[17].split(',')
    if 'bed' in line2[15].split(','):
        print line2[15],'bed'
    if 'fastq paired-end' in line2[15].split(','):
        print 'paired end'
#   continue
    if 'AB SOLiD fastq'  in line[15].split(','):
        print 'AB solid'
        continue
    if re.match(r"^H\d\w*\d",line2[3]):
        factortype="histone"
    elif line2[3].strip() == "DNase":
        factortype="dnase"
    else:
        factortype="tf"
    if line2[13] =='False':
        continue
    print line2,'-------------------------',factortype
#    if line2[13] =='False' or list(set(line2[15].split(',')))[0]!='fastq':
#        i=i+1
#        cmd = 'echo "%s" >> error.backup.human2.txt'%line.strip()
#        print i,line2[14],list(set(line2[14].split(',')))[0]
#        os.system(cmd)
#        continue
    
    cmd = line2[20]
    
    cmd=cmd.replace('/PATH/',tmp_path)
    cmd=cmd.replace(';','\n')
    cmd=cmd.strip()
    print cmd
    print i
#    tmp_out.write(cmd)
    cc = 'sh tmp2.sh'
    if call(cmd,shell = True):
        cont = 'False'+'\t'+line
    else:
        cont = 'True'+'\t'+line
    treatp = line2[18].replace('/PATH/',tmp_path).split(',')
    for iterm in treatp:
        cmd = 'mv %s %s'%(iterm,des_path)
        print cmd
#       os.system(cmd)
    if line2[21]!='none': # download control file 
        cmd = line2[21]
        cmd=cmd.replace('/PATH/',tmp_path)
        cmd=cmd.replace(';','\n')
        cmd=cmd.strip()
        if call(cmd,shell = True):
            cont = 'False'+'\t'+cont
        else:
            cont = 'True'+'\t'+cont
            ctrl = line2[19].replace('/PATH/',tmp_path).split(',')
            for iterm in ctrl:
                cmd = 'mv %s %s'%(iterm,des_path)
                print cmd
#       os.system(cmd)
    else:
        cont = 'True'+'\t'+cont
    out = open(fout,'w')        
    out.write(cont)
    out.close()
fph.close()


#------------------------------
