#!/usr/bin/env python
#Name       :
#Description:
#Usage      :
#------------------------------

import logging
from optparse import OptionParser
from urllib2 import urlopen
import re,os,sys
from subprocess import call

#--------------


#GSMID = sys.argv[1]
#path = sys.argv[2]
#name = sys.argv[3] #name of out file


#------------------------------
logger = logging.getLogger()
hdlr = logging.FileHandler('download_logfile','a+')
formatter = logging.Formatter('%(asctime)s %(levelname)s : %(message)s ;  ')
hdlr.setFormatter(formatter)
logger.addHandler(hdlr)
logger.setLevel(logging.NOTSET)
info = logger.info
error = logger.error
warn = logger.warning


#-------------------------------
def Dtype(DataID):
    if re.findall('GSM',DataID):
        return 'GEO'
    elif re.findall('SRX',DataID) or re.findall('ERX',DataID) or re.findall('DRX',DataID):
        return 'EBI'
    else:
        return False
    
def linkCheck(link):
    try:
    	cont = urlopen(link).readlines()
    	if len(cont)!=0:
        	return True
        else:
        	return False
    except:
        print 'link errr'
        return False


def run(cmd,dry):
    if dry:
        info(cmd)
        return True
    else:
        if call(cmd,shell = True):
    	    print 'error in %s' %cmd
            return False
        else:
            info(cmd)
            return True

        
def GEO(GSMID,path,name,dry):
    link = "http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=%s"%GSMID
    if linkCheck(link):
        siter = urlopen(link).read()
        SRX = re.findall(r'SRX\d*<',siter)
        SRX = list(set(SRX))
        if not SRX: # check ERX
            SRX = re.findall(r'ERX\d*<',siter)
            SRX = list(set(SRX))
            print '#ERX'
        print SRX        
#        print SRX
        if len(SRX)==0:
            print 'warining: no SRX ID'
            error('error: no SRX ID')
            return False,'none','none','none'
        elif len(SRX)==1:
            DataID = SRX[0][0:-1]
            print DataID
            result,dfile,Tcmd,ftype = EBI(GSMID,DataID,path,name,dry)
            return result,dfile,Tcmd,ftype
        else:
            print 'several SRX ID, maybe pair end data'
            error('error: several SRX ID, maybe pair end data')
            return False,'none','none','none'
    else:
            print 'GEO link error'
            error('error: GEO link error')
            return False,'none','none','none'
    
    
    
    
def EBI(GSMID,SRXID,path,name,dry): # if can download return True else return False(if possable to download sra data)
    avaiable=re.compile(r'fastq.gz')
    link="http://www.ebi.ac.uk/ena/data/warehouse/filereport?accession=%s&result=read_run&fields=study_accession,secondary_study_accession,sample_accession,secondary_sample_accession,experiment_accession,run_accession,tax_id,scientific_name,instrument_model,library_layout,fastq_ftp,fastq_galaxy,submitted_ftp,submitted_galaxy,cram_index_ftp,cram_index_galaxy"%SRXID
#    link="http://www.ebi.ac.uk/ena/data/warehouse/filereport?accession=%s&result=read_run&fields=study_accession,secondary_study_accession,sample_accession,secondary_sample_accession,experiment_accession,run_accession,scientific_name,instrument_model,library_layout,fastq_ftp,fastq_galaxy,submitted_ftp,submitted_galaxy,col_tax_id,col_scientific_name"%SRXID
#    link = "http://www.ebi.ac.uk/ena/data/view/reports/sra/fastq_files/%s"%SRXI
    #link = 'http://www.ebi.ac.uk/ena/data/warehouse/filereport?accession=%s&result=read_run&fields=study_accession,secondary_study_accession,sample_accession,secondary_sample_accession,experiment_accession,run_accession,scientific_name,instrument_model,library_layout,fastq_ftp,fastq_galaxy,submitted_ftp,submitted_galaxy,col_tax_id,col_scientific_name,reference_alignment'%SRXID
    print link
    ftype = 'fastq'
    Tcmd=''
    if linkCheck(link):
    	print 'change to EBI'
        siter = urlopen(link).readlines()
        outnamed = os.path.join(path,name+'.fastq.gz')
        outname = os.path.join(path,name+'.fastq')
        rep=len(siter)-1
        print rep
        if rep==1:
            temp=siter[1]
            if len(avaiable.findall(temp))==0:
                print 'not avaiable fastq file'
                error('error: not avaiable fastq file')
                return False,'none',Tcmd,ftype
            elif re.findall('PAIRED',temp):
                ftype = 'fastq paired-end'
                print ftype
                temp = temp.split('\t')
                outnamed1 = os.path.join(path,name+'.fastq_R1.gz')
                outnamed2 = os.path.join(path,name+'.fastq_R2.gz')
                outname1 = os.path.join(path,name+'.fastq_R1')
                outname2 = os.path.join(path,name+'.fastq_R2')
                for iterm in temp:
                    if iterm.startswith('ftp.sra.ebi.ac.uk'):
                        ftp = iterm.strip()
                        print ftp
                        continue
                ftp = ftp.split(';')
                cmd = 'wget -c -t 3 -T 120 %s -O %s'%(ftp[0],outnamed1)
                Tcmd=Tcmd+'\n'+cmd
                cmd = 'wget -c -t 3 -T 120 %s -O %s'%(ftp[1],outnamed2)  
                Tcmd=Tcmd+'\n'+cmd
                if run(Tcmd,dry):
                	print 'succeed precced %s' %cmd
                	info('# finish %s download ' %GSMID) 
                	outnamed =   outnamed1 +';'+outnamed2 
                	return True,outnamed,Tcmd,ftype         
            else:
                temp = temp.split('\t')
                print temp
                for iterm in temp:
                    print iterm,'-------'
                    if iterm.startswith('ftp.sra.ebi.ac.uk'):
                        ftp = iterm.strip()
                        continue
                cmd = 'wget -c -t 3 -T 120 %s -O %s'%(ftp,outnamed)
                Tcmd=Tcmd+'\n'+cmd
                print cmd
                if run(cmd,dry):
                	print 'succeed precced %s' %cmd
                	info('# finish %s download ' %GSMID)
                	return True,outnamed,Tcmd,ftype
        elif rep==0:
            print 'EBI link false'
            error('error: EBI link false\n')
            return False,'none',Tcmd,ftype
        else:
            List = [] # used for cat several fasta file
            if not re.findall('PAIRED',' '.join(siter)):
                for i in range(1,rep+1):
                    temp = siter[i]
                    if len(avaiable.findall(temp))!=0:
                        tempout = os.path.join(path,'%s_%s.fastq'%(name,str(i)))
                        tempoutd = os.path.join(path,'%s_%s.fastq.gz'%(name,str(i)))
                        List.append(tempout)
                        temp = temp.split('\t')
                        for iterm in temp:
                            if iterm.startswith('ftp.sra.ebi.ac.uk'):
                                ftp = iterm.strip()
                                continue
                        cmd = 'wget -c -t 3 -T 120 %s -O %s'%(ftp,tempoutd)
                        Tcmd=Tcmd+'\n'+cmd
                        print cmd
                        if run(cmd,dry):
                        	print 'succeed proceed %s'%cmd
                        	cmd = 'gunzip %s' %tempoutd
                        	Tcmd=Tcmd+'\n'+cmd
                        	print cmd
                        	run(cmd,dry)
                cmd ='cat %s > %s'%(' '.join(List),outname)
                Tcmd=Tcmd+'\n'+cmd
                print cmd
                if  run(cmd,dry):
                	for i in List:
                		cmd = 'rm %s'%i
                		Tcmd=Tcmd+'\n'+cmd
                		print cmd
                	info('#finish %s download'%GSMID)
                	return True,outname,Tcmd,ftype
            else:
                print 'pair end file EBI'
                error('error: pair end file EBI')
                return False,'none',Tcmd,ftype
    else:
        error('error: EBI link error')
        return False,'none',Tcmd,ftype


def BamBed(GSMID,path,name,dry):
    link = "http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=%s"%GSMID
    Tcmd=''
    if linkCheck(link):
        siter = urlopen(link).read()
        bam_r = re.compile(r'%5Ff%2Ebam')
        if re.findall(r'%2Ebed%2Egz',siter):
            bed_rr=re.compile(r'ftp\S*%2Ebed%2Egz"\>\(ftp')
            print '#normal bed'
            bedt = True
        elif re.findall(r'%2Eeland\S*%2Etxt%2Egz',siter):
            bed_rr=re.compile(r'ftp\S*%2Eeland\S*%2Etxt%2Egz"\>\(ftp')
            print '#eland bed'
            bedt = True
        else :
            bedt=False
            print 'bedt false'

        if bedt:
            ftype='bed'
            print bed_rr.findall(siter)
            bed_ftp=bed_rr.findall(siter)[0][0:-6]
            bed_outname = os.path.join(path,name+'.bed.gz')
            cmd ='wget -c -t 3 -T 120 %s -O %s'%(bed_ftp,bed_outname)
            Tcmd=Tcmd+'\n'+cmd
            if run(cmd,dry):
                print 'succeed precced %s' %cmd
                info('# finish %s download ' %GSMID)
                return True,ftype,bed_outname,Tcmd
        elif len(bam_r.findall(siter))!=0:
            ftype='bam'
            bam_rr=re.compile(r'ftp\S*%5Ff%2Ebam">(ftp')
            bam_ftp=bam_rr.findall(siter)[0][0:-6]
            bam_outname = os.path.join(path,name+'.bam')
            cmd  ='wget -c -t 3 -T 120 %s -O %s'%(bam_ftp,bam_outname)
            Tcmd=Tcmd+'\n'+cmd
            if run(cmd,dry):
                print 'succeed precced %s' %cmd
                info('# finish %s download ' %GSMID)
                return True,ftype,bam_outname,Tcmd
        else:
            return False,'unknow Type','none',Tcmd
                


# def main(GSMID,path,name):
def DownloadData(GSMID, path, name,dry):
    """
    Download GEO data for qc pipeline
    Arguments:
    - `GSMID`:
    - `path`:
    - `name`:
    """
    if not os.path.exists(path):
        print '%s not exist'%path
#        sys.exit()
    type = Dtype(GSMID)
    info('#------begin processing %s -o %s'%(GSMID,name))
    if type == 'GEO':
        print '#------begin processing GEO %s'%GSMID
        status,dfile,Tcmd,ftype = GEO(GSMID,path,name,dry)
        if status:
            print status,'fastq',dfile,'Tcmd',Tcmd 
            return status,ftype,dfile,Tcmd
        else:
            status,type,dfile,Tcmd  = BamBed(GSMID,path,name,dry)
            return status,type,dfile,Tcmd
    elif type == 'EBI':
        status,dfile,Tcmd,ftype  = EBI(GSMID,GSMID,path,name,dry)
        return status,ftype,dfile,Tcmd
    else:
        return False,'unknow Type','none','none'
# #------------------------------
# if __name__ == "__main__":
# #    main('GSM951894','/opt/bin')
# #    main('GSM869789','/opt/bin')
# #    main('GSM869784','/opt/bin')
# #    main('GSM801536','/opt/bin')
# #    main('GSM801539','/opt/bin')
# 	 main(GSMID,path,name)


#DownloadData('GSM537668', '/PATH/', GSM537668,True)
