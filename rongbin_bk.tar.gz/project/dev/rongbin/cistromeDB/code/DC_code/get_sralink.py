def sra_link():
    import os
    import urllib2
    import re
    import commands

    input_file = raw_input('input file : ')
    gsm_col = raw_input('which column for GSM : ')
    output = raw_input('output folder : ')
    sbatch_file = open("link.sbatch", "w")
    sbatch_file.write('#!/bin/bash \n\n')
    sbatch_file.close()
    sbatch_file = open("link.sbatch", "a")
    sbatch_file.write('#SBATCH -n 1  #Number of cores \n\n#SBATCH -N 1 \n\n#SBATCH -t 60  #Runtime in minutes \n\n')
    sbatch_file.write('#SBATCH --mem=6900  #Memory per node in MB (see also --mem-per-cpu) \n\n#SBATCH -p serial_requeue \n\n#SBATCH -o xay.log \n#SBATCH -J xay_bwM \n\n')
    PairEnd_gsm = open('PairEnd_gsm.xls', 'w')
    id_infor = {}
    gsm = ''
    srx = ''
    srr = []
    spc = ''
    sra_list = ''
    gsm_list = []
    fastq_list = ''
    file_list = ''
    pair=[]

    for line in open(input_file):
        gsm = line.rstrip().split('\t')[int(gsm_col)]
        print gsm
         # gsm_url is the link of the input GSM data
        try:
            gsm_url = 'http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=%s' % gsm
            gsm_handler = urllib2.urlopen(gsm_url)
            gsm_html = gsm_handler.read()
            # get the ftp location of SRX file and the SRX id
            # ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByExp/sra/SRX/SRX951/SRX951932
            srx_regexp = re.compile('ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByExp/sra/SRX/SRX\S*"')
            srx_infor = srx_regexp.search(gsm_html)
            srx_infor = srx_infor.group().rstrip('"')
            srx = srx_infor.split('/')[-1]
            # get the SRR id('>SRR1588518</a></td><td') and find the type of layout
            srx_url = 'http://www.ncbi.nlm.nih.gov/sra?term=%s' % srx
            srx_handler = urllib2.urlopen(srx_url)
            srx_html = srx_handler.read()
            # find the layout type (<div>Layout: <span>SINGLE</span>)
            lay_infor = re.compile('<div>Layout: <span>.{6}</span>')
            lay_type = lay_infor.search(srx_html)
            lay_type = lay_type.group()
            lay_type = lay_type[-13:-7]
            id_infor[gsm] = lay_type
            # get teh srr id and download the sra files
            srr_regexp = re.compile('>SRR[0-9]*</a></td><td')
            srr = srr_regexp.findall(srx_html)
            if lay_type == 'PAIRED':
                pair.append(gsm)
                print >>PairEnd_gsm, gsm
                continue
            if (len(srr) == 1):
                srr[0] = srr[0][1:-12]
                ftp = srx_infor + '//' + srr[0] + '/' + srr[0] + '.sra'
                sbatch_file.write('wget %s' % ftp + ' -O %s' % output + '/%s' % gsm + '.sra \n')
            elif (len(srr) > 1):
                for i in range(len(srr)):
                    srr[i] = srr[i][1:-12]
                    ftp = srx_infor + '//' + srr[i] + '/' + srr[i] + '.sra'
                    # download the sra files and transmit them into fastq files
                    sbatch_file.write('wget %s' % ftp + ' -O %s' % output + '/%s' % gsm +'_%s'%(i+1)+'.sra \n')
        except:
            out = open('failure_gsm.xls', 'a')
            out.write(gsm+'\n')
            out.close()
            print 'failure gsm : %s'%gsm
    sbatch_file.close()
    print('skip '+str(len(pair))+' paired data:\n'+str(pair))
if __name__ == '__main__':
    sra_link()
