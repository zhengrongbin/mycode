def trans():
    import os
    import commands

    input_table = raw_input('input table path which contains GSM and sequencing  : ')
    gsm_col = raw_input('which column for GSM ID in input file : ')
    type_col = raw_input('which colunm for sequecing type: ')
    sra_file = raw_input('input sra folder : ')
    output = raw_input('output fastq folder : ')
    sbatch_file = open("trans.sbatch", "w")
    trans_gsm = open("trans.gsm","w")
    fail_gsm = open("fail_gsm.xls","w")
    file_list = commands.getoutput('ls '+sra_file)
    sra_list = [x for x in file_list.split('\n') if x.endswith('.sra') and x.startswith('GSM')]
    gsm_list = [x[0:10] for x in file_list.split('\n') if x.endswith('.sra') and x.startswith('GSM')]
    all_gsm = [x.rstrip().split('\t') for x in open(input_table)]
    gsm = ''
    sra = ''
    
    for n in range(len(all_gsm)):
        gsm = all_gsm[n][int(gsm_col)]
        if gsm not in gsm_list:
            print gsm + ' not in'
            fail_gsm.write(gsm+'fail'+'\n')
            continue
        elif all_gsm[n][int(type_col)] == 'fastq':
            sra = [i for i in sra_list if i.startswith(gsm)]
            for j in sra:
                sbatch_file.write('fastq-dump '+sra_file+'/'+j+' --outdir '+output+'\n')
        elif all_gsm[n][int(type_col)] == 'fastq paired-end':
            sra = [i for i in sra_list if i.startswith(gsm)]
            for j in sra:
                sbatch_file.write('fastq-dump'+' --split-3 '+sra_file+ '/'+j+' --outdir '+output+'\n')
        else:
            fail_gsm.write(gsm+'unkown type\n')
            continue
        trans_gsm.write(gsm+'\n')
    sbatch_file.close()
    trans_gsm.close()

if __name__ == '__main__':
    trans()
