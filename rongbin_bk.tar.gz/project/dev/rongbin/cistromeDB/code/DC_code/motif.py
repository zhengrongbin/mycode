import commands
import os

file = open("/data5/home/rongbin/cistromeDB/tables/DC_run_completed_2017.xls.filepath.mapping_peaks.new","r")
file1 = open("File_notexist.txt","w")
file2 = open("File_notfinish.txt","w")
file3 = open("File_noseqlogo.txt","w")
file4 = open("File_Error.txt","w")
path = '/data5/browser/motif_html/'
for i in file.readlines():
	sid = i.rstrip().split('\t')[0]
	factor = i.rstrip().split('\t')[10]
	stype = i.rstrip().split('\t')[11]
	peak = i.rstrip().split('\t')[-1]
	summits = i.rstrip().split('\t')[19]
	if factor[0] == 'H' and stype == 'hm':
		continue
	elif factor == 'DNase':
		continue
	elif factor =='ATAC-seq':
		continue
	elif factor == 'POLR2A':
		continue
	else:
		try:
			if int(peak) < 201:
				continue
			elif not os.path.exists(path+str(sid)+'/'):
				file1.write(str(sid)+'\t'+summits+'\t'+str(peak)+'\n')
			elif os.path.getsize(path+str(sid)+'/motif_list.json') == 0:
				file2.write(str(sid)+'\t'+summits+'\t'+str(peak)+'\n')
			elif len(commands.getoutput('ls /data5/browser/motif_html/%s/seqLogo/'%sid).rstrip().split('\n')) == 1:
				file3.write(str(sid)+'\t'+'/data5/browser/motif_html/%s/seqLogo/draw_seqLogo.r'%sid+'\n')
		except:
			file4.write(str(sid)+'\t'+summits+'\t'+str(peak)+'\n')
file.close()
file1.close()
file2.close()
file3.close()
file4.close()
