#!/usr/bin/env python
"""
main script for data analysis
"""

from optparse import OptionParser
from ConfigParser import ConfigParser

import logging
from subprocess import call as subpcall
from os.path import join as pjoin
import os
import glob
import sys
import re

def run_cmd ( command ):
    subpcall (command,shell=True)

def parse_download(meta):
    content =open(meta).readlines()#[51:]#[33:]#[60:72]#:550
    for line in content:
        line = line.strip().split("\t")
        yield line

def cluster_environment(output, env, meta,fpath):
    for i in parse_download(meta):
        if i[0]=='False':# or i[1]=='False':
            print i[0:8]
            continue
        i = i[2:]
        print i[0:8]
        i[3]=i[3].replace('/','_')
        i[3]=i[3].replace('.','_')
        i[3]=i[3].replace(' ','_')
        if 'bed' in i[15].split(','):
            print i[15]
            continue
        if 'fastq paired-end' in i[15].split(','):
            continue
#        if not ( all(map(lambda x:x=='fastq',i[15].split(','))) and all(map(lambda x:x=='fastq',i[17].split(',')))):
#            continue
        if re.match(r"^H\d\w*\d",i[3]):
            factortype="histone"
            motif_option=" --skip 12 "
             #       continue ## focus on TF first
        elif i[3].strip() == "DNase":
            factortype="dnase"
            motif_option=" --skip 12 "
            #        continue ## focus on TF first
        else:
            factortype="tf"
            motif_option=" "
                #    continue
        ftype = i[3].strip().lower() 
        if ftype in ['h3k27me3', 'h3k36me3', 'h3k9me3']:
            peaktype = "broad"
        else:
            peaktype = "narrow"
               
        tr2 = i[18].replace('/PATH/',fpath)
        cont2 = i[19].replace('/PATH/',fpath)
        treat = tr2
        tr = i[18].replace('/PATH/',fpath).split(',')
        cont = i[19].replace('/PATH/',fpath).split(',')
        if i[12] == 'NoControl':
            control = ' '
            tmp=tr
        else:
            control = " -c " + cont2
            treat=i[18].replace('/PATH/',fpath)   
            print i[19] 
            tmp=tr+cont
        tr = i[18].replace('/PATH/',fpath).split(',')
        cont = i[19].replace('/PATH/',fpath).split(',')        
        fname = i[11]+'.sbatch'#os.path.join(output, i[1]+"_"+factortype) 
        f = open(fname, 'w')
        f.write(open(env, 'rU').read())
        if os.path.exists(treat):
              fsize=os.path.getsize(treat)/1024/1024
        else:
              continue
        if fsize<10:
              continue
        if fsize > 20000:
              time='3000'
              fmemory='36222'
              cmd='echo %s >> big.txt'%i[1]
              os.system(cmd)
        if fsize > 16000:
              time='2800'
              fmemory='26222' 
        if fsize > 7000:
              print 'up 5GB'
              time='2400'
              fmemory='22222'
        elif fsize > 3500:
              print 'up 3GB'
              time='1600'
              fmemory='15000'
        elif fsize > 2000:
              time='1100'
              fmemory='11000'
        elif fsize > 1000:
              time='900'
              fmemory='10000'
              print 'up 1GB'
        elif fsize > 500:
              time='700'
              fmemory='8900'
              print 'less than 1GB'
        else:
              time='400'
              fmemory='8900'
        print 'size',fsize
        f.write("#SBATCH -t %s \n" %time)
        f.write("#SBATCH --mem=%s \n" % fmemory)
        f.write("#SBATCH -o %s.log \n" % i[11])
        f.write("#SBATCH -J %s \n" % i[11])
        f.write("source /n/home04/xiaoleliu/MEI/DC_env/chilin/chilin_env/bin/activate \n")
        outfpath="dataset_"+i[11]
        outfpath=os.path.join(output,outfpath)
        if i[2]=='Homo sapiens':
             cmd="chilin simple -u qinq -s hg38 --threads 8 -i %s -o %s -t %s %s  -p %s -r %s %s \n" % (i[11], outfpath, treat, control, peaktype, factortype, motif_option)
             f.write("\nchilin simple -u qinq -s hg38 --skip 12 --threads 8 -i %s -o %s -t %s %s  -p %s -r %s %s \n" % (i[11], outfpath, treat, control, peaktype, factortype, motif_option))
        else:
            f.write("\nchilin simple -u qinq -s mm10 --threads 8 -i %s -o %s -t %s %s  -p %s -r %s %s \n" % (i[11], outfpath, treat, control, peaktype, factortype, motif_option))
            cmd="chilin simple -u qinq -s mm10 --threads 8 -i %s -o %s -t %s %s  -p %s -r %s %s \n" % (i[11], outfpath, treat, control, peaktype, factortype, motif_option)
        print cmd
#        cmd='python /n/regal/xiaoleliu_lab/xiaoleliu/meisl/codeNew/re_RUN/res_check.py %s  \n'%outfpath
#        f.write(cmd)
        cmd = "sbatch %s" % i[11]+'.sbatch'#"_"+factortype
        stat='True'
        for term in tmp:
              if not os.path.exists(term):
                     stat='Fasle'
        if stat=='True':
              cmd2 = "echo %s >> Newsh_rerun_check.sh"%cmd
        else:
              cmd2 = "echo %s >> Newsh_rerun.error.sh"%cmd
        os.system(cmd2) 
        if True:#subpcall (command,shell=True):
            print 'False'
        else:
            print 'True'
#        report = os.path.join("/n/regal/xiaoleliu_lab/xiaoleliu/DC/GEO/dataset"+i[1], i[1]+"_"+i[3]+".pdf")
#       f.write("\n if [ -s %s ]; then" % report)
#            f.write("\n chmod 775 %s" % ("/n/regal/xiaoleliu_lab/xiaoleliu/DC/GEO/dataset"+i[1]))
#       if i[2]=='Homo sapiens':
#           f.write("\n scp -P 33001 -r %s smei@cistrome.org:/data5/DC_results/hg38/ \n" % ("/n/regal/xiaoleliu_lab/xiaoleliu/DC/GEO/dataset"+i[1]))
#       else:
#           f.write("\n scp -P 33001 -r %s smei@cistrome.org:/data5/DC_results/mm10/ \n" % ("/n/regal/xiaoleliu_lab/xiaoleliu/DC/GEO/dataset"+i[1]))
#            f.write("\n if [ $? -ne 0 ]; then  ")
#            f.write("\n echo %s >> re_copy"%("/n/regal/xiaoleliu_lab/xiaoleliu/DC/GEO/dataset"+i[1]))
#            f.write("\n else ")
#       f.write("\n rm -r %s \n" % ("/n/regal/xiaoleliu_lab/xiaoleliu/DC/GEO/dataset"+i[1]))
#       f.write("\n rm -r %s \n" % ' '.join(tr))
#            if "NoControl" not in cont[0]:
#           f.write("\n rm -r  %s  \n" % ' '.join(cont))
#       f.write("\n echo %s >> done" % i[1])
#            f.write("\n fi\n")
#       f.write("\n else\n")
#       f.write("\n echo %s >> not_done" % i[1])
#       f.write("\n fi\n")
#       f.close()
#       cmd = "sbatch %s" % i[1]+"_"+factortype
        #os.system(cmd)
#            print cmd
#       cmd2 = "echo %s >> Newsh_rerun.sh"%cmd
#       os.system(cmd2)
#       cmd3 = "echo %s >> submit.id"%report
#       os.system(cmd)


def main():
    usage = "python %prog config"
    description = """ for analyzing chip seq data """
    optparser = OptionParser(version="%prog 1",description=description,usage=usage,add_help_option=False)
    optparser.add_option("-h","--help",action="help",help="Show this help message and exit.")
    optparser.add_option("-o","--output", dest="o", type=str, help="Show this help message and exit.")
    optparser.add_option("-e","--env", dest="env", type=str, help="Show this help message and exit.")
    optparser.add_option("-m","--meta", dest="meta", type=str, help="Show this help message and exit.")        
    optparser.add_option("-v","--verbose",dest="verbose",action="store_true", help="")
    optparser.add_option("-p","--fpath", dest="fpath", type=str, help="Show this help message and exit.")  
    (options,args) = optparser.parse_args()

    if not options.meta or not options.o:
        optparser.print_help()
        sys.exit(1)
        
    output = options.o
    meta = options.meta
    env = options.env
    fpath=options.fpath
    #gcap_prepare(output, env, meta)
    cluster_environment(output, env, meta,fpath)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.stderr.write("User interrupt me! ;-) See you!\n")
        sys.exit(1)
