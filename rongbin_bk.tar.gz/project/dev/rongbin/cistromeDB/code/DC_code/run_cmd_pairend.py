def chilin():
  import commands,os
  input_table = raw_input('input table path which contains GSM and species : ')
  gsm_col = raw_input('which column for GSM ID in input file : ')
  seq_col = raw_input('which column for sequence type:')
  fastq_folder = raw_input('raw fastq folder : ')
  save_folder = raw_input('result svaed folder : ')
  species_types = raw_input('species one or two : ')
  if species_types == 'one':
  	species = raw_input('species hg38/mm10 : ')
  elif species_types == 'two':
  	species_col = raw_input('which column for species in input file : ')
  type = raw_input('factor type (histone/tf/dnase) : ')
  out = open('submit_cmd_paired.sh', 'w')
  all_gsm = [x.rstrip().split('\t') for x in open(input_table)]
  expert = []
  for n in range(len(all_gsm)):
    gsm = all_gsm[n][int(gsm_col)]
    seq_new = all_gsm[n][int(seq_col)]
    if seq_new != "unknow Type":
        fail_notpaire = open('Not_paired_end.xls','a')
        print 'Not_paired:%s'%gsm
        fail_notpaire.write(gsm+'\n')
        continue
    if species_types == 'two':
      species_new = all_gsm[n][int(species_col)]
      if species_new == 'Homo sapiens':
    	  species = 'hg38'
      elif species_new == 'Mus musculus':
    	  species = 'mm10'
      else:
    	  continue
    print gsm
    fastq_path1 = os.path.join(fastq_folder, gsm+'.fastq_R1')
    fastq_path2 = os.path.join(fastq_folder, gsm+'.fastq_R2')
#    fsize=os.path.getsize(fastq_path)/1024/1024
    if not os.path.exists(fastq_path1):
      fastq_path1 = 'NA'
      fail_file = open('Failure_fastq.xls', 'a')
      print 'failure: %s'%gsm
      fail_file.write(gsm+'\n')
      continue
    fsize=os.path.getsize(fastq_path2)/1024/1024
    if fsize==0:
          continue
    if fsize > 7000:
          print 'up 5GB'
          time='3600'
          fmemory='222222'
    elif fsize > 3500:
          print 'up 3GB'
          time='1800'
          fmemory='19200'
    elif fsize > 2000:
          time='1500'
          fmemory='13200'
    elif fsize > 1000:
          time='1200'
          fmemory='12000'
          print 'up 1GB'
    elif fsize > 500:
          time='900'
          fmemory='10680'
          print 'less than 1GB'
    else:
          time='600'
          fmemory='9480'
    print 'size',fsize
    cmd = 'chilin simple --pe -u qinq -s %s --threads 12 -i %s -o %s -t %s,%s  -p narrow -r %s --skip 12'%(species, gsm, os.path.join(save_folder, 'dataset_'+gsm), fastq_path1, fastq_path2,type)
    expert.append(cmd)
    #n = 1
    #if len(expert) == 10:
    sbatch_file = open("run_%s.sbatch"%gsm, "w")
    sbatch_file.write('#!/bin/bash \n\n')
    sbatch_file.write('#SBATCH -n 8  #Number of cores \n\n#SBATCH -N 1 \n\n#SBATCH -t %s  #Runtime in minutes \n\n'%time)
    sbatch_file.write('#SBATCH --mem=%s  #Memory per node in MB (see also --mem-per-cpu) \n\n#SBATCH -p serial_requeue \n\n#SBATCH -o %s.log \n#SBATCH -J %s \n\n'%(fmemory,gsm, gsm))
    sbatch_file.write('source /n/home04/xiaoleliu/MEI/DC_env/chilin/chilin_env/bin/activate \n\n')
    #for x in cmd:
    print >>sbatch_file, cmd
    print >>out, 'sbatch run_%s.sbatch'%gsm
    sbatch_file.close()


if __name__ == '__main__':
    chilin()
