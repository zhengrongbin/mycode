import os
import urllib2
import re
import commands
import argparse

###This code still require the checking read length script
# def check_read(fastq_file):
#     with open(fastq_file) as fastq:
#         line1 = fastq.readline()
#         read_len = len(fastq.readline())
#     return read_len

# transfer the sra files to fastqfiles and cat the multiple fastq files
def catfastq(gsm,srx_infor,srr,lay_type,output):
    cmd = ''
    cat_file1 = ''
    cat_file2 = ''
    if lay_type == 'SINGLE':
        for i in range(len(srr)):
            srr[i] = srr[i][1:-12]
            ftp = srx_infor + '//' + srr[i] + '/' + srr[i] + '.sra'
            # download the sra files and transmit them into fastq files
            cmd = cmd + 'wget %s' % ftp + ' -O %s' % output + '/%s' % gsm +'_%s'%(i+1)+'.sra \n'
            cmd = cmd + 'fastq-dump ' + '%s' % output + '/%s' % gsm +'_%s'%(i+1)+'.sra \n'
            cat_file1 = cat_file1 + '%s' % output + '/%s' % gsm +'_%s'%(i+1)+'.fastq '
        cmd = cmd + 'cat ' + cat_file1 +'> ' + '%s' % gsm +'.fastq \n'
        # cmd = cmd + 'rm ' + cat_file1 +'\n'
    elif lay_type == 'PAIRED':
        for i in range(len(srr)):
            srr[i] = srr[i][1:-12]
            ftp = srx_infor + '//' + srr[i] + '/' + srr[i] + '.sra'
            cmd = cmd + 'wget %s' % ftp + ' -O %s' % output + '/%s' % gsm +'_%s'%(i+1)+'.sra \n'
            cmd = cmd + 'fastq-dump -I --split-files ' + '%s' % output + '/%s' % gsm +'_%s'%(i+1)+'.sra \n'
            cat_file1 = cat_file1 + '%s' % output + '/%s' % gsm +'_%s'%(i+1)+'_1.fastq '
            cat_file2 = cat_file2 + '%s' % output + '/%s' % gsm +'_%s'%(i+1)+'_2.fastq '
        cmd = cmd + 'cat ' +cat_file1+'> ' + '%s' % gsm +'.fastq_R1 \n'
        cmd = cmd + 'cat ' +cat_file2+'> ' + '%s' % gsm +'.fastq_R2 \n'
        # cmd = cmd + 'rm ' + cat_file1 + cat_file2 + '\n'
    else:
        print 'lay_type error'
    return cmd

# get link and download sra files
def sra_link(input_file,gsm_col,output):
    SingleEnd_gsm = open('SingleEnd.xls', 'w')
    PairEnd_gsm = open('PairEnd.xls','w')
    id_infor = {}
    gsm = ''
    srx = ''
    srr = []
    spc = ''
    sra_list = ''
    gsm_list = []
    fastq_list = ''
    file_list = ''
    single = []
    pair = []
    for line in open(input_file):
        gsm = line.rstrip().split('\t')[int(gsm_col)-1]
        print gsm
        sbatch_file = open("%s.sbatch" % gsm, "w")
        sbatch_file.write('#!/bin/bash \n\n')
        # sbatch_file.close()
        # sbatch_file = open("%s.sbatch" % gsm, "a")
        sbatch_file.write('#SBATCH -n 1  #Number of cores \n\n#SBATCH -N 1 \n\n#SBATCH -t 60  #Runtime in minutes \n\n')
        sbatch_file.write('#SBATCH --mem=6900  #Memory per node in MB (see also --mem-per-cpu) \n\n#SBATCH -p serial_requeue \n\n#SBATCH -o GEOdown.log \n#SBATCH -J GEO_down \n\n')
        sbatch_file.write('source /n/home04/xiaoleliu/MEI/DC_env2/bin/activate \n\n')
        # gsm_url is the link of the input GSM data
        try:
            gsm_url = 'http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=%s' % gsm
            gsm_handler = urllib2.urlopen(gsm_url)
            gsm_html = gsm_handler.read()
            # get the ftp location of SRX file and the SRX id
            # ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByExp/sra/SRX/SRX951/SRX951932
            srx_regexp = re.compile('ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByExp/sra/SRX/SRX\S*"')
            srx_infor = srx_regexp.search(gsm_html)
            srx_infor = srx_infor.group().rstrip('"')
            srx = srx_infor.split('/')[-1]
            # get the SRR id('>SRR1588518</a></td><td') and find the type of layout
            srx_url = 'http://www.ncbi.nlm.nih.gov/sra?term=%s' % srx
            srx_handler = urllib2.urlopen(srx_url)
            srx_html = srx_handler.read()
            # find the layout type (<div>Layout: <span>SINGLE</span>)
            lay_infor = re.compile('<div>Layout: <span>.{6}</span>')
            lay_type = lay_infor.search(srx_html)
            lay_type = lay_type.group()
            lay_type = lay_type[-13:-7]
            id_infor[gsm] = lay_type
            # get the srr id and download the sra files
            srr_regexp = re.compile('>SRR[0-9]*</a></td><td')
            srr = srr_regexp.findall(srx_html)
            if lay_type == 'SINGLE':
                 single.append(gsm)
                 print >>SingleEnd_gsm, gsm
            elif lay_type == 'PAIRED':
                 pair.append(gsm)
                 print >>PairEnd_gsm, gsm
            sbatch_file.write(catfastq(gsm,srx_infor,srr,lay_type,output)+'\n')
            sbatch_file.close()
        except:
            out = open('Failure_gsm.xls', 'a')
            out.write(gsm+'\n')
            out.close()
            print 'failure gsm : %s'%gsm
        

def main():
    try:
        parser = argparse.ArgumentParser(description="""download srr file and translate to fastq""")
        parser.add_argument( '-i', dest='inputable', type=str, required=True, help='path of the input table')
        parser.add_argument( '-gc', dest='gsmcolumn', type=str, required=True, help='the column of gsm ID')
        parser.add_argument( '-o', dest='outputdir', type=str, required=True, help='directory of output file')
        args = parser.parse_args()
        sra_link(args.inputable,args.gsmcolumn,args.outputdir)
    except KeyboardInterrupt:
        sys.stderr.write("User interrupted me!\n")
        sys.exit(0)

if __name__ == '__main__':
    main()
