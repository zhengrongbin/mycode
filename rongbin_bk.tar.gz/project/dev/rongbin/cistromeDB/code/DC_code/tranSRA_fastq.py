
def trans():
    import os
    import urllib2
    import re
    import commands

    sra_file = raw_input('input sra folder : ')
    output = raw_input('output folder : ')
    sbatch_file = open("trans.sbatch", "w")
    sbatch_file.write('#!/bin/bash \n\n')
    sbatch_file.close()
    sbatch_file = open("trans.sbatch", "a")
    cat_file = open("cat.sbatch", "a")
    sbatch_file.write('#SBATCH -n 1  #Number of cores \n\n#SBATCH -N 1 \n\n#SBATCH -t 160  #Runtime in minutes \n\n')
    sbatch_file.write('#SBATCH --mem=6900  #Memory per node in MB (see also --mem-per-cpu) \n\n#SBATCH -p serial_requeue \n\n#SBATCH -o trans.log \n#SBATCH -J trans \n\n')
    sbatch_file.write('source /n/home04/xiaoleliu/MEI/DC_env/chilin/chilin_env/bin/activate \n\n')
    cat_file.write('#SBATCH -n 1  #Number of cores \n\n#SBATCH -N 1 \n\n#SBATCH -t 160  #Runtime in minutes \n\n')
    cat_file.write('#SBATCH --mem=6900  #Memory per node in MB (see also --mem-per-cpu) \n\n#SBATCH -p serial_requeue \n\n#SBATCH -o trans.log \n#SBATCH -J trans \n\n')
    cat_file.write('source /n/home04/xiaoleliu/MEI/DC_env/chilin/chilin_env/bin/activate \n\n')
    file_list = commands.getoutput('ls '+sra_file)
    sra_list = [x for x in file_list.split('\n') if x.endswith('.sra') and x.startswith('GSM')]
    gsm_all = []
    for i  in sra_list:
        file_name = i[:-4]
        #print('fastq-dump -A ' +file_name + ' ' + sra_file + '/' + file_name + '.sra --outdir ' + output)
        sbatch_file.write('fastq-dump -A ' +file_name + ' ' + sra_file + '/' + file_name + '.sra --outdir ' + output+'\n')
        gsm = i.split('_')[0]
        gsm_all.append(gsm)
    for i in list(set(gsm_all)):
        gsm_re = re.compile(i)
        gsm_list = gsm_re.findall(file_list)
        nsra = len(gsm_list)
        if (nsra > 1):
            #a=gsm+'_1.sra'
            #loc1 = sra_list.index(gsm+'_1.sra')
            print i, nsra
            print('cat ')
            cat_file.write('cat ')
            for j in range(nsra):
                print(output+'/'+i+'_'+str(j+1)+'.fastq ')
                cat_file.write(output+'/'+i+'_'+str(j+1)+'.fastq ')
            cat_file.write('> '+output+'/'+i+'.fastq\n')
            print('> '+output+'/'+i+'.fastq')
        else:
            continue

if __name__ == '__main__':
    trans()
