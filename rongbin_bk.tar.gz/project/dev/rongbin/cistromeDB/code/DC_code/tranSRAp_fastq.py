def trans():
    import os
    import commands

    sra_file = raw_input('input sra folder : ')
    output = raw_input('output folder : ')
    sbatch_file = open("trans.sbatch2", "w")
    trans_gsm = open("trans.gsm2","w")
    file_list = commands.getoutput('ls '+sra_file)
    sra_list = [x for x in file_list.split('\n') if x.endswith('.sra') and x.startswith('GSM')]
    for i  in sra_list:
        file_name = i[0:10]
        #print('fastq-dump -A ' +file_name + ' ' + sra_file + '/' + file_name + '.sra --outdir ' + output)
        sbatch_file.write('/n/regal/xiaoleliu_lab/liwei/zhengrb/software/sratoolkit.2.8.1-ubuntu64/bin/fastq-dump --split-3 ' + sra_file + '/' + file_name + '.sra --outdir ' + output+'\n')
        gsm = i.split('_')[0]
        trans_gsm.write(gsm+'\n')
    sbatch_file.close()
    trans_gsm.close()

if __name__ == '__main__':
    trans()

