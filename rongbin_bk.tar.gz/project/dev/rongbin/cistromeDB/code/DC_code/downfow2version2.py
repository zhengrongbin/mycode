#!/usr/bin/env python
#Author     : shenglin mei
#Name       :
#Description:
#Usage      :
#------------------------------
from optparse import OptionParser
import os,sys
from GSMdown2 import DownloadData
import time
import argparse

# fin = sys.argv[1]
# fout = sys.argv[2]
# dir = sys.argv[3]

#time.asctime()


def downflow(fin,fout,dir,dry,ct,cc,start):
    fph = open(fin)
    out = open(fout,'w')
    dry = True
    downlist = []
    typelist = []
    ct = int(ct)-1   #column number of treat
    cc = int(cc)-1  # column number of control
    count=1
    for line in fph:
        print count
        if count < int(start):   #970 1139 
            count=count+1
            continue
        linesp = line.strip('\n').split('\t')
#        count = count+1
        print 'length',len(linesp),ct,cc,linesp[cc]
#        print linesp
        if linesp[cc]=='' or linesp[cc]=='NA' or linesp[cc]=='NoControl':
            print 'NoControl'
            control_index=False
        else:
            control_index=True
            print 'have control'
        tGSMIDs = linesp[ct]
        
        time.sleep(10)
#        print GSMID
        tstatus = []
        ttypes = []
        cstatus = []
        ctypes = []
        tfile=[]
        cfile=[]
        tcode=[]
        ccode=[]
        tGSMIDs = tGSMIDs.split(',')
        
        for GSMID in tGSMIDs:
            GSMID = str(GSMID.strip().strip('"'))
            if True: #GSMID not in downlist:
                test,type,dfile_treat,Tcmd_treat = DownloadData(GSMID,dir,GSMID,dry)
                if test:
                    tstatus.append('True')
                    ttypes.append(type)
                    tfile.append(dfile_treat)
                    tTcmd_treat=Tcmd_treat.replace('\n',';')
                    tcode.append(tTcmd_treat)
                    print '# success process %s'%GSMID
                else:
                    print '# error download %s'%GSMID
                    tstatus.append('False')
                    ttypes.append(type)
            else:
                print '# already download %s'%GSMID
                tstatus.append('True')
                inde = downlist.index(GSMID)
                ttypes.append(typelist[inde])
        if control_index:
            cGSMIDs = linesp[cc]
            cGSMIDs = cGSMIDs.split(',')
            for GSMID in cGSMIDs:
                GSMID = str(GSMID.strip().strip('"'))
                if True: #GSMID not in downlist:
                    test,type,dfile_control,Tcmd_control = DownloadData(GSMID,dir,GSMID,dry)
                    if test:
                        downlist.append(GSMID)
                        typelist.append(type)
                        cstatus.append('True')
                        ctypes.append(type)
                        cfile.append(dfile_control)
                        tTcmd_control=Tcmd_control.replace('\n',';')
                        ccode.append(tTcmd_control)
                        print '# success process %s'%GSMID
                    else:
                        print '# error download %s'%GSMID
                        cstatus.append('False')
                        ctypes.append(type)
                else:
                    print '# already download %s'%GSMID
                    cstatus.append('True')
                    inde = downlist.index(GSMID)
                    ctypes.append(typelist[inde])
            #tmd_c = Tcmd_control.replace('\n',';')
        else:
            ctypes.append('none')
            cstatus.append('none')
            dfile_control='none'
            tmd_c = 'none'
            cfile.append('none')
            ccode.append('none')
       # tstatus = list(set(tstatus))
       # cstatus = list(set(cstatus))
        status_list =  tstatus+cstatus
        if status_list.count('False'):
            final = 'False'
        else:
            final = 'True'
#        outr = ','.join(tstatus)+'\t'+','.join(ttypes)+'\t'+','.join(cstatus)+'\t'+','.join(ctypes)+'\t'+final+'\t'+line.strip('\n')+'\n'
#        tmd_t = Tcmd_treat.replace('\n',';')
#        tmd_c = Tcmd_control.replace('\n',';')
#        print Tcmd_treat,Tcmd_control
        outr = str(count)+'\t'+'\t'.join(linesp[0:12])+'\t'+final+'\t'+','.join(tstatus)+'\t'+','.join(ttypes)+'\t'+','.join(cstatus)+'\t'+','.join(ctypes)+'\t'+','.join(tfile)+'\t'+','.join(cfile)+'\t'+';'.join(tcode)+'\t'+';'.join(ccode)+'\n'
        print outr
        count = count+1
        print ','.join(tfile),','.join(cfile),';'.join(tcode),';'.join(ccode)
        out.write(outr)
    out.close()

#------------------------------

def downflow2(treat,dir,control=''):
    dry = True
    treat = treat.split(',')
    TTcmd=''
    downlist = [] # should be deleted; make nonesense 
    typelist = []
    if True:
        print dir
#        print linesp
        if control=='':
            print 'NoControl'
            control_index=False
        else:
            control_index=True
            control = control.split(',')
        
        time.sleep(5)
#        print GSMID
        tstatus = []
        ttypes = []
        cstatus = []
        ctypes = []
        dfile_t=[]
        dfile_c=[]
        for GSMID in treat:
            if GSMID not in downlist:
                test,type,dfile,Tcmd = DownloadData(GSMID,dir,GSMID,dry)
                TTcmd = TTcmd+'\n'+Tcmd+'\n'
                dfile_t.append(dfile)
                if test:
                    typelist.append(type)
                    tstatus.append('True')
                    ttypes.append(type)
                    print '# success process %s'%GSMID
                else:
                    print '# error download %s'%GSMID
                    tstatus.append('False')
                    ttypes.append(type)
            else:
                print '# already download %s'%GSMID
                tstatus.append('True')
                inde = downlist.index(GSMID)
        if control_index:
            print control
            for GSMID in control:
                if GSMID not in downlist:
                    test,type,dfile,Tcmd = DownloadData(GSMID,dir,GSMID,dry)
                    TTcmd = TTcmd+'\n'+Tcmd+'\n'
                    dfile_c.append(dfile)
                    if test:
                        typelist.append(type)
                        cstatus.append('True')
                        ctypes.append(type)
                        print '# success process %s'%GSMID
                    else:
                        print '# error download %s'%GSMID
                        cstatus.append('False')
                        ctypes.append(type)
                else:
                    print '# already download %s'%GSMID
                    cstatus.append('True')
                    inde = downlist.index(GSMID)
                    ctypes.append(typelist[inde])
        else:
            ctypes.append('none')
            cstatus.append('none')
       # tstatus = list(set(tstatus))
       # cstatus = list(set(cstatus))
        status_list =  tstatus+cstatus
        if status_list.count('False'):
            final = 'False'
        else:
            final = 'True'
        print final,','.join(dfile_t),','.join(dfile_c)
        print 'total download script',TTcmd
        return final,','.join(dfile_t),','.join(dfile_c),TTcmd


#downflow(['GSM1174484'],['GSM1174484'],'/home/smei/Workplace/DC/code')




def main():
	parser = argparse.ArgumentParser(description='This is a PyMOTW sample program')
	sub_parsers = parser.add_subparsers(help = "sub-command help", dest = "sub_command")
	template_parser = sub_parsers.add_parser("run",  help = "run pipeline",description = "run pipeline")
	template_parser.add_argument("-f","--file",dest="file",help=" GSM file")
	template_parser.add_argument("-o","--output",dest="output",help="output")
	template_parser.add_argument("--dry-run", dest="dry_run", action="store_true", default=False)
	template_parser.add_argument("-p","--outputpath",dest="outputpath", help="the path of download file")
	template_parser.add_argument("-t","--col_treat",dest="col_treat",default=2)
	template_parser.add_argument("-c", "--col_control",dest="col_control",default=3)
	template_parser.add_argument("-s", "--start",dest="start",default=3)
	pipe_parser = sub_parsers.add_parser("simple", help = "run pipeline using simple mode",description = "simple model")
	pipe_parser.add_argument("-p","--outputpath",dest="outputpath",help="the path of download file")
	pipe_parser.add_argument("-t","--treat",dest="treat")
	pipe_parser.add_argument("-c", "--control",dest="control")
	args = parser.parse_args()
	if args.sub_command == "run":
		print args.file
		downflow(args.file,args.output,args.outputpath,args.dry_run,args.col_treat,args.col_control,args.start)
	if args.sub_command == "simple":
		print args
		downflow2(args.treat,args.outputpath,args.control)



if __name__=='__main__':
      main()




