import os
#DC_path = ['/data5/DC_results/Result_new3', '/data5/DC_results/Result_new2', '/data1/DC_results/Result_new', '/data5/DC_results/Result_new', '/data2/DC_results/Result_new', '/data3/DC_results/Result_new', '/data6/DC_results/Result_encode3/', '/data6/DC_results/Result_2016_ATAC', '/data6/DC_results/Result_2016_k27ac', '/data6/DC_results/Result_2016All']
DC_path = ['/data6/DC_results/Result_2016All']
for d in DC_path:
	res = [os.path.join(d, x) for x in os.listdir(d) if x.startswith('dataset')]
	for s in res:
		#treat_bw = [os.path.join(s, i) for i in os.listdir(s) if i.endswith('_treat.bw')]
		# if treat_bw:
		# 	f = open('treat_bw.xls', 'a')
		# 	f.write(treat_bw[0] + '\n')
		# 	f.close()
		control_bw = [os.path.join(s, ii) for ii in os.listdir(s) if ii.endswith('_control.bw')]
		if control_bw:
			f = open('control_bw.sh', 'a')
			f.write('rm -f '+control_bw[0] + '\n')
			f.close()
