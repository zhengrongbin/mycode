import sys,os
file = sys.argv[1]
specis = sys.argv[2] #column
factor_type = sys.argv[3]#column
summit = sys.argv[4]#column

f = [x.rstrip().split('\t') for x in open(file)]
get = []
out = open('conser.sh', 'w')
for x in f:
	#ID = x[int(summit)].split('/')[-1].replace('dataset', '').strip('_')
	ID = x[int(summit)].split('/')[-1].strip('_sort_summits.bed')
	if x[int(factor_type)] == 'tf':
		w = 400
	else:
		w = 4000 
	cmd1 = 'head -n 5000 %s | cut -f 1,2,3,4,9 > %s'%(x[int(summit)], x[int(summit)].split('/')[-1]+'.top5000')
	if x[int(specis)] == 'Homo sapiens':
		#cmd = 'python /data5/home/smei/zhengrb/cistrome/conservation/conservation/conservation_plot.py -d /data5/DC_results/ChilinENV/chilin/db/hg38/phastcon.bw -w %d -o %s %s'%(w, x[0], x[int(summit)])
		cmd2 = '/data5/DC_results/ChilinENV/chilinENV_olddasiy/local/lib/python2.7/site-packages/chilin2-2.0.0-py2.7.egg/chilin2/modules/conservation/conservation_onebw_plot.py -d /data5/DC_results/ChilinENV/chilin/db/hg38/phastcon.bw -w %d -o %s %s'%(w, ID, x[int(summit)].split('/')[-1]+'.top5000')
		#print >>out, cmd
	else:
		#cmd = 'python /data5/home/smei/zhengrb/cistrome/conservation/conservation/conservation_plot.py -d /data5/DC_results/ChilinENV/chilin/db/mm10/phastcon.bw -w %d -o %s %s'%(w, x[0], x[int(summit)])
		cmd2 = '/data5/DC_results/ChilinENV/chilinENV_olddasiy/local/lib/python2.7/site-packages/chilin2-2.0.0-py2.7.egg/chilin2/modules/conservation/conservation_onebw_plot.py -d /data5/DC_results/ChilinENV/chilin/db/mm10/phastcon.bw -w %d -o %s %s'%(w, ID, x[int(summit)].split('/')[-1]+'.top5000')
                #print >>out, cmd
	cmd3 = 'convert -resize 500x500 -density 50 %s.pdf %s_conserv_img.png'%(ID, ID)
	path = os.path.join('/'.join(x[int(summit)].split('/')[:-1]), 'attic')
	cmd4 = 'cp %s_conserv_img.png %s'%(ID, path)
	out.write(cmd1+'\n'+cmd2+'\n'+cmd3+'\n'+cmd4+'\n')
out.close()
