import sys,os,re
import argparse
import subprocess

def map_peaks(filepath, dir_column):
	if os.path.isfile(filepath):
		f=[x.rstrip('\n').split('\t') for x in open(filepath).readlines()]
		type='file'
	if os.path.isdir(filepath):
		f=[os.path.join(filepath, x) for x in os.listdir(filepath) if x.startswith('dataset')]
		type='dir'
	get=[]
	for iterm in f:
		if type == 'file':
			dir=iterm[int(dir_column)]
			path=os.path.join(dir, 'attic/json/%s_map.json'%dir.split('/')[-1])
			path_macs=os.path.join(dir, 'attic/json/%s_macs2.json'%dir.split('/')[-1])
			print dir
		if type == 'dir':
			path=os.path.join(iterm, 'attic/json/%s_map.json'%iterm[iterm.index('dataset')+7:].rstrip('/'))
			path_macs=os.path.join(iterm, 'attic/json/%s_macs2.json'%dir[dir.index('dataset')+7:].rstrip('/'))
			iterm=[iterm.split('/')[-1]]
			print iterm
		if os.path.exists(path):
			try:
				map_file=open(path, 'r').read()
				total=re.findall(r'"total": \d*', map_file)[0][9:]
				mapped=re.findall(r'"mapped": \d*', map_file)[0][10:]
				ratio=str(float(mapped)/float(total)*100)
				#macs_file = open(path_macs, 'r').read()
				#peaks = re.findall(r'"totalpeak": \d*', macs_file)[0][13:]
			#	map_file.close()
				#macs_file.close()
				l=iterm + [total, mapped, ratio]

			except KeyboardInterrupt:
				print "json file cannot open"
		else:
			l=iterm + ['NA', 'NA', 'NA']
		
		if os.path.exists(path_macs):
			macs_file = open(path_macs, 'r').read()
			peaks = re.findall(r'"totalpeak": \d*', macs_file)[0][13:]
		#	macs_file.close()	
			l.append(peaks)
		else:
			l.append('NA')
		
		get.append(l)
			
	out=open(filepath+'.mapping_peaks', 'w')
	for x in get:
		print >>out, '\t'.join(x)
	out.close()
	return get

def main():
	try:
		parser = argparse.ArgumentParser(description="""caculate mapping ratio and peak number""")
		parser.add_argument( '-f', dest='filepath', type=str, required=True, help='the file contains dictory path' )
		parser.add_argument( '-c', dest='dir_column', type=str, required=True, help='which column is the dictory inf' )
		
		args = parser.parse_args()
		
		map_peaks(args.filepath, args.dir_column)
		
	except KeyboardInterrupt:
		sys.stderr.write("User interrupted me!\n")
		sys.exit(0)
		
if __name__ == '__main__':
	main()
		
		
# sort -n -k 3 mapping_rate.txt > mapping_rate.txt.sorted
