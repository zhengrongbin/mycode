import os,sys
p = sys.argv[1] # the path of file directory
topath = sys.argv[2] # the path of daisy
save_file = sys.argv[3]

file_list = os.listdir(p)
files = [os.path.join(p, x) for x in file_list if x.startswith('dataset')]

sbatch_file = open(save_file, 'w')

time = 1000
fmemory = 400

sbatch_file.write('#!/bin/bash \n\n')
sbatch_file.write('#SBATCH -n 1  #Number of cores \n\n#SBATCH -N 1 \n\n#SBATCH -t %s  #Runtime in minutes \n\n'%time)
sbatch_file.write('#SBATCH --mem=%s  #Memory per node in MB (see also --mem-per-cpu) \n\n#SBATCH -p serial_requeue \n\n#SBATCH -o scp.log \n#SBATCH -J scp \n\n'%fmemory)

for x in files:
  cmd = 'scp -r -P 33001 %s rongbin@cistrome.org:%s'%(x, topath)
  print >>sbatch_file, cmd

sbatch_file.close()
