import os,sys
dic = sys.argv[1]

allsample = [x for x in os.listdir(dic) if x.startswith('ENC')]
out = open('data_directory.txt', 'w')
for x in allsample:
	print >>out, '\t'.join([x, os.path.join(dic, x)])
out.close()
