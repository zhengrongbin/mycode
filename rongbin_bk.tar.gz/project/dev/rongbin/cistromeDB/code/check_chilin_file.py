import sys,os
import argparse
import subprocess

def add_filepath(dirpath, cmd):
#"""add columns information about path of pdf, xls, peak, bam files and json"""

    	get=[]	
#	f = open(str(table_path)).readlines()
#	f = [x.rstrip('\n').split('\t') for x in f]
	f=[dirpath]
	for i in f:
#		path = os.path.join(dirpath, i)
		path=dirpath
		if path and os.path.isdir(path):
			i = [i]
			dataset = os.listdir(path)	
			peak=[i1 for i1 in dataset if i1.endswith('sort_peaks.narrowPeak') or i1.endswith('sort_peaks.narrowPeak.bed') or i1.endswith('sort_peaks.broadPeak.bed') or i1.endswith('sort_peaks.broadPeak.bed') and i1.find('rep') == -1]
			if peak:
				path_peak = os.path.join(path, ''.join(peak))
				i.append(path_peak)
			else:
				i.append('NA')

			xls=[i1 for i1 in dataset if i1.endswith('peaks.xls') and i1.find('rep') == -1]
			if xls:
				path_xls = os.path.join(path, ''.join(xls))
				i.append(path_xls)
			else:
				i.append('NA')
			bw = [i1 for i1 in dataset if i1.endswith('treat.bw')]
			if bw:
				path_bw = os.path.join(path, ''.join(bw))
				i.append(path_bw)
			else:
				i.append('NA')
			summit = [i1 for i1 in dataset if i1.endswith('sort_summits.bed')]
                        if summit:
                                path_summit = os.path.join(path, ''.join(summit))
                                i.append(path_summit)
                        else:   
                                i.append('NA')
			p_attic = os.path.join(path, 'attic')
			if 'attic' in dataset and os.path.isdir(p_attic):
				attic = os.listdir(p_attic)
				if 'json' in attic and os.path.isdir(os.path.join(p_attic, 'json')):
					path_json = os.path.join(p_attic, 'json')
					i.append(path_json)
				else:
					i.append('NA')			
				treat=[i1 for i1 in attic if i1.endswith('bam') and i1.find('treat') != -1]
				if treat and len(treat) == 1:
					path_bam = os.path.join(p_attic, ''.join(treat))
					i.append(path_bam)
				elif treat and len(treat) > 1:
					treatment = [i2 for i2 in treat if i2.find('treatment') != -1]
					if treatment:
						path_bam = os.path.join(p_attic, ''.join(treatment))
						i.append(path_bam)
					else:
						i.append('NA treatment.bam')
				else:
					i.append('NA')
			else:
				i.append('NA')
		else:
		        i.append('NA')
	
		get.append(i)
#	wrong=[]
#	ok=[]
	for x in get:
		l=[]
		for i in x:
			if i == "NA":
				l.append(i)
		if not l:
			print 'files checked OK'
#			ok.append(x)
			return
		elif l:
#			wrong.append(x)
			os.system("rm -r %s"%dirpath)
			os.system(cmd)

#			print cmd

	return 

def main():
	try:
		parser = argparse.ArgumentParser(description="""check chilin result and rerun if error happened""")
		parser.add_argument( '-d', dest='dirpath', type=str, required=True, help='dictory path of chilin result need to check')
		parser.add_argument( '-c', dest='cmd', type=str, required=True, help='ChiLin command for rerun')

		args = parser.parse_args()
		
		add_filepath(args.dirpath, args.cmd)

	except KeyboardInterrupt:
		sys.stderr.write("User interrupted me!\n")
		sys.exit(0)

if __name__ == '__main__':
	main()
	
