import sys,os

f1 = sys.argv[1] #input file
col = sys.argv[2] #chilin result path column

f = [x.rstrip().split('\t') for x in open(f1)]
out1, out2 = open('%s.conser_ok'%f1, 'w'), open('%s.conser_no'%f1, 'w')
col = int(col)
for sample in f:
	dict = sample[col]
	id = dict.split('dataset')[-1]
	conser_file = os.path.join(dict, 'attic/%s_conserv_img.png'%id)
	if os.path.exists(conser_file):
		print >>out1, '\t'.join(sample+[conser_file])
	elif not os.path.exists(conser_file):
		print >>out2, '\t'.join(sample+['None'])
	else:
		print sample

out1.close()
out2.close()
