import sys,os
import argparse
import subprocess

def add_filepath(inputpath, col):

    get=[]
    #file_list = [x.rstrip().split('\t') [int(col)] for x in open(inputpath)]
    file_list = [x.rstrip().split('\t') for x in open(inputpath)]
    for i in file_list:
        path=i[int(col)]
        if path and os.path.isdir(path):
#            i = [i]
            dataset = os.listdir(path)
            peak=[i1 for i1 in dataset if i1.endswith('sort_peaks.narrowPeak') or i1.endswith('sort_peaks.narrowPeak.bed') or i1.endswith('sort_peaks.broadPeak.bed') or i1.endswith('sort_peaks.broadPeak.bed') and i1.find('rep') == -1]
            if peak:
                path_peak = os.path.join(path, ''.join(peak))
                i.append(path_peak)
            else:
                i.append('NA')
            xls=[i1 for i1 in dataset if i1.endswith('peaks.xls') and i1.find('rep') == -1]
            if xls:
                path_xls = os.path.join(path, ''.join(xls))
                i.append(path_xls)
            else:
                i.append('NA')
            bw = [i1 for i1 in dataset if i1.endswith('treat.bw')]
            if bw:
                path_bw = os.path.join(path, ''.join(bw))
                i.append(path_bw)
            else:
                i.append('NA')
            p_attic = os.path.join(path, 'attic')
            if 'attic' in dataset and os.path.isdir(p_attic):
                attic = os.listdir(p_attic)
                if 'json' in attic and os.path.isdir(os.path.join(p_attic, 'json')):
                    path_json = os.path.join(p_attic, 'json')
                    i.append(path_json)
                else:
                    i.append('NA')
                score = [i1 for i1 in attic if i1.endswith('score.txt')]
                if score:
                    path_score = os.path.join(p_attic, ''.join(score))
                    i.append(path_score)
                else:
                    i.append('NA')
                treat=[i1 for i1 in attic if i1.endswith('bam') and i1.find('treat') != -1]
                if treat and len(treat) == 1:
                    path_bam = os.path.join(p_attic, ''.join(treat))
                    i.append(path_bam)
                elif treat and len(treat) > 1:
                    treatment = [i2 for i2 in treat if i2.find('treatment') != -1]
                    if treatment:
                        path_bam = os.path.join(p_attic, ''.join(treatment))
                        i.append(path_bam)
                    else:
                        i.append('NA treatment.bam')
                else:
                    i.append('NA')
            else:
                i.append('NA')
        else:
            i.append('NA')

        get.append(i)

    finish = open('finished.xls','w')
    fail = open('failed.xls','w')
    for x in get:
        l=[]
        finish = open('finished.xls', 'a')
        fail = open('failed.xls', 'a')
        for i in x:
            if i == "NA":
                l.append(i)
        if not l:
            print x[0]+' files checked OK'
            finish.write(x[0]+'\t'+x[1]+'\n')
        elif l:
            fail.write(x[0]+'\t'+x[1]+'\n')
            #os.system("rm -r %s"%dirpath)
            # #os.system(cmd)



def main():
    try:
        parser = argparse.ArgumentParser(description="""check chilin result and rerun if error happened""")
        parser.add_argument( '-i', dest='inputpath', type=str, required=True, help='file path which contains chilin result need to check')
        parser.add_argument( '-c', dest='col', type=str, required=True, help='column for chilin result directory')

        args = parser.parse_args()

        add_filepath(args.inputpath, args.col)

    except KeyboardInterrupt:
        sys.stderr.write("User interrupted me!\n")
        sys.exit(0)

if __name__ == '__main__':
    main()

