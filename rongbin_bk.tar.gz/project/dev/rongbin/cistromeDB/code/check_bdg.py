import sys,os
import argparse

def add_filepath(table_path, dirpath_column, output_path):
#"""add columns information about path of pdf, xls, peak, bam files and json"""

	dirpath_column = int(dirpath_column)    		
	f = open(str(table_path)).readlines()
	f = [x.rstrip('\n').split('\t') for x in f]
	for i in f:
		if i[dirpath_column] != 'none':
			path = i[dirpath_column]
			dataset = os.listdir(path)	
			p_attic = os.path.join(path, 'attic')
			if 'attic' in dataset and os.path.isdir(p_attic):
				attic = os.listdir(p_attic)
				bdg_cntl = [i1 for i1 in attic if i1.endswith('.bdg') and i1.find('control') != -1] 
				bdg_treat = [i1 for i1 in attic if i1.endswith('.bdg') and i1.find('treat') != -1]
				if bdg_cntl:
					i.append(bdg_cntl[0])
				else:
					i.append('NA')	
				if bdg_treat:
					i.append(bdg_treat[0])
				else:
					i.append('NA')	
		if (i[-1] == 'NA' and i[-2] == 'NA'):
			continue
		ff = open(str(output_path), 'a')
		#for x in f:
		ff.write('\t'.join(i)+'\n')			
		ff.close()
	
	return


def main():
        try:
                parser = argparse.ArgumentParser(description="""find files from chilin result""")
                parser.add_argument( '-f', dest='inputfile_path', type=str, required=True, help='raw data file which contains tha path for chilin result dictory' )
                parser.add_argument( '-c', dest='dictory_col', type=str, required=True, help='dictory stored chilin result' )
                parser.add_argument( '-s', dest='save_path', type=str, required=True, help='the file name where would like to save to')


                args = parser.parse_args()

                add_filepath(args.inputfile_path, args.dictory_col, args.save_path)


        except KeyboardInterrupt:
                sys.stderr.write("User interrupted me!\n")
                sys.exit(0)

if __name__ == '__main__':
        main()
               
