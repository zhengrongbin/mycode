import requests
import urllib
import os,sys
from bs4 import BeautifulSoup
import sys,os,json
import re
import codecs




def ENCODEparse2(ENCODE):
#ENCODE=fph[1].strip().split('\t')
    ENCODEID=ENCODE[0]
    fin=ENCODEID+'.json'
    finp=os.path.join('/data5/DC_results/mei/GEO/ENCODE2/dat2/',fin)
    C_content=open(finp).read()
    Cjson=json.loads(C_content) 
    biosample_type='NA'
    dbxrefs='NA'
    lab='NA'
    aliases='NA'
    nucleic_acid_term_name='NA'
    size_range='NA'
    chip_control_acc='NA'
    target='NA'
    target1='NA'
    sp='NA'
    technical_replicate_number='NA'
    biological_replicate_number='NA'
    biosample_type=Cjson['biosample_type']
    lab=Cjson['lab']['name']
    dbxrefs=Cjson['dbxrefs']  #
    
    if len(dbxrefs)==0:
        dbxrefs='NA'
    else:
        dbxrefs='|'.join(dbxrefs)
    
    aliases=Cjson['aliases'] 
    try:
        nucleic_acid_term_name=Cjson['replicates'][0]['library']['nucleic_acid_term_name']
        size_range=Cjson['replicates'][0]['library']['size_range']
    except:
        pass
    try:
        sp=Cjson['target']['organism']['scientific_name']
        target1=Cjson['target']['name']
        target=Cjson['target']['label']
    except:
        pass
    try:
        biological_replicate_number=Cjson['replicates'][0]['biological_replicate_number']
        technical_replicate_number=Cjson['replicates'][0]['technical_replicate_number']
        project=Cjson['replicates'][0]['library']['documents'][0]['award']['project']
    except:
        project='NA'
    if Cjson['documents']:
        project=Cjson['documents'][0]['award']['project']
    try:
        chip_control_acc=Cjson['possible_controls'][0]['accession']
    except:
        pass
    our=[ENCODEID,project,biosample_type,dbxrefs,lab,nucleic_acid_term_name,size_range,sp,target1,target,chip_control_acc,biological_replicate_number,technical_replicate_number]
    print our
    return our






fph=open('ENCODEALL_out.xls').readlines()
out=open('ENCODEALL_out_add.xls','w')
ids=1
for i in fph:
    i=i.strip().split('\t')
    print i[0]
 #   our=ENCODEparse2(i)
    try:
        our=ENCODEparse2(i)
        our=[str(ii) for ii in our]
        our=i+our
        our='\t'.join(our)+'\n'
        print our
        out.write(our)
        print ids
        ids=ids+1
    except:
        pass
