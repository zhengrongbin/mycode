
import requests
import urllib
import os,sys
from bs4 import BeautifulSoup
import sys,os,json
import re
import codecs


def ENCODEparse(ENCODE):
    fin=ENCODE+'.json'
    finp=os.path.join('/data5/DC_results/mei/GEO/ENCODE2/dat2/',fin)
    C_content=open(finp).read()
    annotaion=['biosample_type','biosample_synonyms','accession','biosample_term_name','target']
    Cjson=json.loads(C_content) 
    biosample_term_name='NA'
    assay_term_name='NA'
    description='NA'
    month_released='NA'
    biosample_term_name=Cjson['biosample_term_name']
    assay_term_name=Cjson['assay_term_name']
    description=Cjson['description']
    month_released=Cjson['month_released']
    our=[ENCODE,biosample_term_name,assay_term_name,month_released]
    print our
    return our
    



fph=open('ENCODEALL.id.extra').readlines()
out=open('ENCODEALL_out.xls','w')
ids=1
for i in fph:
    print i
    i=i.strip()
    try:
        our=ENCODEparse(i)
        our=[str(i) for i in our]
        our='\t'.join(our)+'\n'
#        print our
        out.write(our)
        print ids
        ids=ids+1
    except:
        pass

out.close()



