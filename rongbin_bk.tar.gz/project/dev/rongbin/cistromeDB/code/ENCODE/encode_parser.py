import requests
import urllib
import os,sys
from bs4 import BeautifulSoup
import sys,os,json
import re
import pandas as pd
import argparse

def _merge_fastq2(fastqs_ann_runtype, runtype):
    """merge fastq based on sequence type (single or paired)
    """
    res = {}
    for br in fastqs_ann_runtype['bioRep'].unique().tolist(): # loop for each biological replicates
        res[br] = []
        fastqs_ann_runtype_br = fastqs_ann_runtype[fastqs_ann_runtype['bioRep']==br]
        for end in fastqs_ann_runtype_br['end'].unique().tolist(): # loop for the same end of sequence
            tmp = fastqs_ann_runtype_br[fastqs_ann_runtype_br['end']==end]
            res[br].append(','.join(tmp['fastq'].tolist())) # the different run with same end should be merged, so mark as ,
        res[br] = [';'.join(res[br]), runtype, ';'.join([str(x/1014/1024)+'Mb' for x in fastqs_ann_runtype_br['file_size'].tolist()])]# the different end should be keept, so mark as ;
    return(res)


def _merge_fastq1(fastqs_ann):
    """merge fastq annotation based on biological replicates
    """
    res1 = {}
    ends = fastqs_ann['run_type'].unique()
    for runtype in fastqs_ann['run_type'].unique().tolist():
        fastqs_ann_runtype = fastqs_ann[fastqs_ann['run_type']==runtype]
        fastqs_ann_runtype = fastqs_ann_runtype.sort_values(by = ['bioRep', 'end'])
        res1.update(_merge_fastq2(fastqs_ann_runtype, runtype))
    return(res1)

def _fastq_parser(fastqs):
    '''parse fastq annotation
    '''
    fastqs_ann = []
    for fastq in fastqs:
        link = fastq['href']
        run_type = fastq['run_type']
        file_size = fastq['file_size']
        biological_replicate, technical_replicate = fastq['technical_replicates'][0].split('_')
        if run_type == 'paired-ended':
            end = fastq['paired_end']
        else:
            end = '0'
        fastqs_ann.append([biological_replicate, end, link, run_type, file_size])
    fastqs_ann=pd.DataFrame(fastqs_ann, columns = ['bioRep', 'end', 'fastq', 'run_type', 'file_size'])
    return(_merge_fastq1(fastqs_ann))

def ENCODEparse2(jsonDir,ENCODEID):
    """parse the meta annotation from the json file for given sample
    """
    fin=ENCODEID+'.json'
    finp=os.path.join(jsonDir,fin)
    C_content=open(finp).read()
    Cjson=json.loads(C_content)
    biosample_summary = 'NA'
    biosample_term_name = 'NA'
    biosample_type='NA'
    dbxrefs='NA'
    lab='NA'
    aliases='NA'
    target='NA'
    target1='NA'
    target_type = 'NA'
    sp='NA'
    biosample_term_name = Cjson['biosample_term_name']
    biosample_summary = Cjson['biosample_summary']
    biosample_type=Cjson['biosample_type']
    lab=Cjson['lab']['name']
    dbxrefs=Cjson['dbxrefs']  #

    if len(dbxrefs)==0:
        dbxrefs='NA'
    else:
        dbxrefs='|'.join(dbxrefs)
    aliases=Cjson['aliases']
    try:
        sp=Cjson['target']['organism']['scientific_name']
        target1=Cjson['target']['name']
        target=Cjson['target']['label']
        if target.upper() in ['DNASE-SEQ', 'ATAC-SEQ']:
            target_type = 'ca'
        elif re.match(r"^H\d\w*\d",target):
            target_type = 'histone'
        else:
            target_type = 'tf'
    except:
        pass
        
    #parse fastq 
    try:
        fastqs = [x for x in Cjson['files'] if x['file_type'] == 'fastq']
        fastq_ann = _fastq_parser(fastqs)
    except:
        pass

    if len(fastq_ann.keys())>1:
        content = []
        for i in fastq_ann.keys():
            link, run_type, file_size = fastq_ann[i]
            content.append([ENCODEID, str(ENCODEID)+'_'+str(i), sp, run_type, link, file_size, target, target_type, target1,biosample_summary, biosample_term_name, biosample_type,dbxrefs,lab])
    elif len(fastq_ann) == 1:
        link, run_type, file_size = fastq_ann[fastq_ann.keys()[0]]
        content=[[ENCODEID, str(ENCODEID), sp, run_type, link, file_size, target, target_type, target1, biosample_summary, biosample_term_name, biosample_type,dbxrefs,lab]]
    else:
        link, run_type, file_size = 'NA', 'NA', 'NA'
        content=[[ENCODEID, str(ENCODEID), sp, run_type, link, file_size, target, target_type, target1, biosample_summary, biosample_term_name, biosample_type,dbxrefs,lab]]
    return content

#fph=open('ENCODEALL_out.xls').readlines()
#out=open('ENCODEALL_out_add.xls','w')
#ids=1
#for i in fph:
#    i=i.strip().split('\t')
#    print i[0]
# #   our=ENCODEparse2(i)
#    try:
#        our=ENCODEparse2(i)
#        our=[str(ii) for ii in our]
#        our=i+our
#        our='\t'.join(our)+'\n'
#        print our
#        out.write(our)
#        print ids
#        ids=ids+1
#    except:
#        pass
        
def _download_json(ID):
    """download json file from ENCODE website based on accession ID
    """
    if not os.path.exists('encode_json'):
        os.mkdir('./encode_json')
    link = 'https://www.encodeproject.org/experiments/%s'%ID + '/?format=json'
    outputfile = './encode_json/'+ID+'.json'
    link += ' -O %s'%outputfile
    print link
    os.system('wget '+link)
    return True

def _readFile(fpath, cid, fsave):
    """read given file and get the ENCODE accession ids
    """
    cid = int(cid)
    with open(fpath) as dat:
        for line in dat:
            ID = line.rstrip().split('\t')[cid]
            if not ID.startswith('ENC'):
                continue
            # download json file
            dstatus = _download_json(ID)
            # do the parser
            content = ENCODEparse2('./encode_json', ID)
            for one in content:
                one=[str(ii.encode("utf-8")) for ii in one]
                out = open(fsave, 'a')
                out.write('\t'.join(one)+'\n')
                out.close()
            print ID
            
def main():
        try:
                parser = argparse.ArgumentParser(description="""parse encode samples""")
                parser.add_argument( '-f', dest='inputfile_path', type=str, required=True, help='the table at least on column which is ENCODE sample accession ID' )
                parser.add_argument( '-c', dest='id_col', type=str, required=True, help='The column of the ENCODE sample ID in the given file, start from 0' )
                parser.add_argument( '-o', dest='save', type=str, required=True, help='the file that save the meta annotation' )
    

                args = parser.parse_args()

                _readFile(args.inputfile_path, args.id_col, args.save)


        except KeyboardInterrupt:
                sys.stderr.write("User interrupted me!\n")
                sys.exit(0)

if __name__ == '__main__':
        main()
