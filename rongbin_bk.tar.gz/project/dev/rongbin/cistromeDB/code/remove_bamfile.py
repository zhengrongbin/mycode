#!/usr/bin/python
#coding:utf-8
import os,sys
import argparse

def findall(fsave, add = False):
	"""scan all the bam files from the given path
	"""
	DC_path = ['/data5/DC_results/Result_new3', '/data5/DC_results/Result_new2', '/data1/DC_results/Result_new', '/data5/DC_results/Result_new', '/data2/DC_results/Result_new', '/data3/DC_results/Result_new', '/data6/DC_results/Result_encode3/', '/data6/DC_results/Result_2016_ATAC', '/data6/DC_results/Result_2016_k27ac']
	out = open(fsave, 'w')
	out.close()
	if add and ',' in add:
		DC_path = DC_path+add.split(',')
	elif add and not ',' in add:
		DC_path.append(add)
	for p in DC_path:
		print p
		all_samples = [x for x in os.listdir(p) if x.startswith('dataset')]
		for s in all_samples:
			sub_dir = os.path.join(p, s+'/attic')	
			bam = [x for x in os.listdir(sub_dir) if x.endswith('.bam')]
			if not bam:
				continue
			for b in bam:
				cmd = 'rm -f %s'%os.path.join(sub_dir, b)
				out = open(fsave, 'a')
				out.write(cmd+'\n')
			out.close()		

def get_cmd(factor, sp, sa, htype = False):
	"""scan bam files by types
	"""
	if sp == 'human':
		sp = 'Homo sapiens'
	else:
		sp = 'Mus musculus'
	f = [x.rstrip().split('\t') for x in open('/data5/home/rongbin/cistromeDB/tables/DC_run_completed_2017.xls.filepath.new') if sp in x]
	if factor in ['ATAC-seq', 'DNase']:
		filter_get = [x for x in f if x[10] == factor]
	elif factor == 'hm':
		if not htype:
			filter_get = [x for x in f if x[10].startswith('H')]
		elif htype and htype != 'else':
			filter_get = [x for x in f if x[10].startswith('H') and x[10] == htype]
		elif htype and htype == 'else':
			filter_get = [x for x in f if x[10].startswith('H') and x[10] not in ['H3K4me3', 'H3K27ac', 'H3K27me3', 'H3K9me3', 'H3K36me3', 'H3K4me1']]
	else:
		filter_get = [x for x in f if (x[10] not in ['ATAC-seq', 'DNase']) and (not x[10].startswith('H'))]
	out = open(sa, 'w')
	for ii in filter_get:
		if os.path.exists(ii[21]):
			cmd = 'rm %s'%ii[21]
			print >>out, cmd
	out.close()

def main():
	try:
		parser = argparse.ArgumentParser(description="""get bam file deletion commands""")
		sub_parsers = parser.add_subparsers(help = "sub-command help", dest = "sub_command")
		all_parser = sub_parsers.add_parser("all",  help = "scan all",description = "get bam files from all storage path")
		all_parser.add_argument('-sf', dest='all_save_file', type = str, required = True, help='save file path')
		all_parser.add_argument('-ad', dest='add_directory', type = str, required = False, help='more directory for DC sample storage')
		part_parser = sub_parsers.add_parser("part",  help = "scan bam by pattern",description = "get bam files by types")
		part_parser.add_argument( '-t', dest='factor_type', type=str, required=True, help='factor type, including ATAC-seq, DNase, tf, hm')
                part_parser.add_argument( '-ht', dest='histone_type', type=str, required=False, help='histone subtype: H3K4me3, H3K27ac, H3K27me3, H3K9me3, H3K36me3, H3K4me1, and else')
		part_parser.add_argument('-sp',dest='species',type=str,required=True,help='species you want to remove, human or mouse')
		part_parser.add_argument( '-sa', dest ='save_file', type=str,required=True, help='the command file you want to save')
		args = parser.parse_args()
		if args.sub_command == 'all':
			if args.add_directory:
				findall(args.all_save_file, args.add_directory)
			else:
				findall(args.all_save_file, False)
		if args.sub_command == 'part':
			if args.histone_type:
				get_cmd(args.factor_type, args.species, args.save_file, args.histone_type)
			else:
				get_cmd(args.factor_type, args.species, args.save_file, False)
		#word = args.dirpath.strip().split(',')
		# for line in word:
		# 	if args.c is not None:
		# 		add_filepath(line,args.p, args.c)
		# 	else:
		# 		add_filepath(line,args.p)

	except KeyboardInterrupt:
		sys.stderr.write("User interrupted me!\n")
		sys.exit(0)

if __name__ == '__main__':
	main()
