import sys,os
import argparse

def add_filepath(table_path, dirpath_column, output_path):
#"""add columns information about path of pdf, xls, peak, bam files and json"""

	dirpath_column = int(dirpath_column)    		
	f = open(str(table_path)).readlines()
	f = [x.rstrip('\n').split('\t') for x in f]
	for i in f:
		if i[dirpath_column] != 'none':
			path = i[dirpath_column]
			dataset = os.listdir(path)	
			peak=[i1 for i1 in dataset if ((i1.endswith('sort_peaks.narrowPeak')) or (i1.endswith('sort_peaks.narrowPeak.bed')) or (i1.endswith('sort_peaks.broadPeak')) or (i1.endswith('sort_peaks.broadPeak.bed'))) and (i1.find('rep') == -1)]
			if peak:
				path_peak = os.path.join(path, ''.join(peak))
				i.append(path_peak)
			else:
				i.append('NA')
			xls=[i1 for i1 in dataset if i1.endswith('peaks.xls') and i1.find('rep') == -1]
			if xls:
				path_xls = os.path.join(path, ''.join(xls))
				i.append(path_xls)
			else:
				i.append('NA')
                        bw = [i1 for i1 in dataset if i1.endswith('treat.bw')]
                        if bw:
                                path_bw = os.path.join(path, ''.join(bw))
                                i.append(path_bw)
                        else:
                                i.append('NA')
                        summit = [i1 for i1 in dataset if i1.endswith('sort_summits.bed')]
                        if summit:
                                path_summit = os.path.join(path, ''.join(summit))
                                i.append(path_summit)
                        else:
                                i.append('NA')
			p_attic = os.path.join(path, 'attic')
			if 'attic' in dataset and os.path.isdir(p_attic):
				attic = os.listdir(p_attic)
				gene_score_fold = [i1 for i1 in attic if i1.endswith('_gene_score.txt')]
				if gene_score_fold and len(gene_score_fold) == 1:
					path_beta_fold = os.path.join(p_attic, gene_score_fold[0])
					i.append(path_beta_fold)
				else:
					i.append('NA')
				gene_score = [i1 for i1 in attic if i1.endswith('_gene_score_5fold.txt')]
				if gene_score and len(gene_score) == 1:
					path_beta = os.path.join(p_attic, gene_score[0])
					i.append(path_beta)
				else:
					i.append('NA')
				if 'json' in attic and os.path.isdir(os.path.join(p_attic, 'json')):
					path_json = os.path.join(p_attic, 'json')
					i.append(path_json)
				else:
					i.append('NA')			
				treat=[i1 for i1 in attic if i1.endswith('bam') and i1.find('treat') != -1]
				if treat and len(treat) == 1:
					path_bam = os.path.join(p_attic, ''.join(treat))
					i.append(path_bam)  
				elif treat and len(treat) > 1:
					treatment = [i2 for i2 in treat if i2.find('treatment') != -1]
					if treatment:
						path_bam = os.path.join(p_attic, ''.join(treatment))
						i.append(path_bam)
					else:
						i.append('NA treatment.bam')
				else:
					i.append('NA')
					
		ff = open(str(output_path), 'a')
		#for x in f:
		ff.write('\t'.join(i)+'\n')			
		ff.close()
	
	return


def main():
        try:
                parser = argparse.ArgumentParser(description="""find files from chilin result""")
                parser.add_argument( '-f', dest='inputfile_path', type=str, required=True, help='raw data file which contains tha path for chilin result dictory' )
                parser.add_argument( '-c', dest='dictory_col', type=str, required=True, help='dictory stored chilin result' )
                parser.add_argument( '-s', dest='save_path', type=str, required=True, help='the file name where would like to save to')


                args = parser.parse_args()

                add_filepath(args.inputfile_path, args.dictory_col, args.save_path)


        except KeyboardInterrupt:
                sys.stderr.write("User interrupted me!\n")
                sys.exit(0)

if __name__ == '__main__':
        main()
               
