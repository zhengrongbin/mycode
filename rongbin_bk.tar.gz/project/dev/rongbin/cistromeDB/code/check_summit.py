import sys, os

f1 = sys.argv[1]
col = sys.argv[2] #col for directory

f = [x.rstrip().split('\t') for x in open(f1)]
col = int(col)
out = open('%s.summit'%os.path.basename(f1), 'w')
for sample in f:
	dict = sample[col]
        id = dict.split('dataset')[-1]
	summit_file = [x for x in os.listdir(dict) if x.endswith('_sort_summits.bed')]
	if summit_file:
		print >>out, '\t'.join(sample+[os.path.join(dict, summit_file[0])])
	else:
		print >>out, '\t'.join(sample+['None'])

out.close()
