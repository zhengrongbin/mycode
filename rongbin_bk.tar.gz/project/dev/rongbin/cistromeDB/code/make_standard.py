import sys
raw_file = sys.argv[1]
species_col = sys.argv[2]
factor_col = sys.argv[3]
gsmid_col = sys.argv[4]

#def normalize(raw_file):
dc = [x.rstrip("\n").split("\t") for x in open(raw_file)]
get=[]
for x in dc:
	l=['NA', x[int(species_col)], x[int(factor_col)], 'NA', 'new', 'none', 'none', 'none', 'none', 'NA', x[int(gsmid_col)], 'NoControl', 'new']
	get.append(l)
out=open("%s.bed"%raw_file.split('/')[-1], "w")
for x in get:
	print >>out, "\t".join(x)
out.close()
