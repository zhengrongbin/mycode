import sys,os
import argparse
import subprocess


def run_cmd(command,os_path="./"):
	child = subprocess.Popen(command, shell = True, cwd = os_path)
	child.wait()

	
	
def runMACS(file_path, bam_column, factor_column, save_path):
#	data=[x.rstrip('\n').split('\t') for x in open(file_path)]
	out=open('bamTobw.sh', 'w')
	g=[]
	for iterm in open(file_path):
		x=iterm.rstrip('\n').split('\t')
		print x[bam_column] 
		print x[factor_column]
		if 'Homo sapiens' in iterm:
			sp = 'hs'
			chrom = '/data5/DC_results/ChilinENV/chilin/db/hg38/chrom.bed'
			chromInfo = '/data5/DC_results/ChilinENV/chilin/db/hg38/chromInfo_hg38.txt'
		else:
			sp = 'mm'
			chrom = '/data5/DC_results/ChilinENV/chilin/db/mm10/chrom.bed'
			chromInfo = '/data5/DC_results/ChilinENV/chilin/db/mm10/chromInfo_mm10.txt'
		bamfile=x[int(bam_column)]
		name=bamfile.split('/')[-1].split('_treat_rep1.bam')[0]
		if x[factor_column] in ['H3K9me3', 'H3K27me3', 'H3K36me3']:
			peak_type = 'broad'
			cmd1 = 'macs2 callpeak --SPMR -B -q 0.01 --keep-dup 1 --broad --broad-cutoff 0.01 -g %s -t %s -n %s'%(sp, bamfile, os.path.join(save_path, name))
		else:
			peak_type = 'narrow'
			cmd1='macs2 callpeak --SPMR -B -q 0.01 --keep-dup 1 --extsize=100 --nomodel -g %s -t %s -n %s'%(sp, bamfile, os.path.join(save_path, name))

		cmd2='bedtools intersect -a %s/%s_treat_pileup.bdg -b %s -wa -f 1.00 > %s/%s_treat_pileup.bdg.tmp'%(save_path, name, chrom, save_path, name)
		cmd3='bedGraphToBigWig %s/%s_treat_pileup.bdg.tmp %s %s/%s_treat.bw'%(save_path, name, chromInfo, save_path, name)	
		cmd4='rm %s/%s_treat_pileup.bdg.tmp'%(save_path, name)
		out.write(cmd1+'\n'+cmd2+'\n'+cmd3+'\n'+cmd4+'\n')	
	out.close()			


def main():
        try:
                parser = argparse.ArgumentParser(description="""from bam to bigwig""")
                parser.add_argument( '-f', dest='inputfile_path', type=str, required=True, help='raw data file which contains bam file path' )
                parser.add_argument( '-bc', dest='Bam_file_col', type=int, required=True, help='Bam file column in -f file' )
		parser.add_argument( '-fc', dest='factor_col', type = int, required=True, help='factor name column in -f file' )
                parser.add_argument( '-s', dest='save_path', type=str, required=True, help='the file name where would like to save to')


                args = parser.parse_args()

                runMACS(args.inputfile_path, args.Bam_file_col, args.factor_col, args.save_path)


        except KeyboardInterrupt:
                sys.stderr.write("User interrupted me!\n")
                sys.exit(0)

if __name__ == '__main__':
        main()
