import os,sys
import argparse
from optparse import OptionParser

def _excute(FromPath, ToPath):
    ret, commands = [], []
    ls = os.listdir(FromPath)
    for df in ls:
        path = os.path.join(FromPath, df)
        if os.path.isfile(path):
            ret.append(path)
            folderTo = path.replace(os.path.basename(path), '').replace(FromPath.replace(os.path.basename(FromPath), ''), ToPath+'/')
            cmd1 = 'mkdir {}'.format(folderTo+'\n')
            if not os.path.exists(folderTo) and cmd1 not in commands:
                commands.append(cmd1)
                f = open('copyXML.sh', 'a')
                f.write(cmd1)
                f.close()
            cmd = 'cp ' + path + ' ' + path.replace(FromPath, folderTo)
            if not os.path.exists(path.replace(FromPath, folderTo)):
                commands.append(cmd)
                f = open('copyXML.sh', 'a')
                f.write(cmd+'\n')
                f.close()
        else:
            newd = os.path.join(FromPath, df)
            ret = _excute(newd, ToPath)
    return ret

def main():
    try:
        xml_parser = argparse.ArgumentParser(description="""copy xml files from path_one to path_two.""")
        xml_parser.add_argument('-pone', dest='pathFrom', type=str, required = True, help="The folder path of 'FROM' xml files.")
        xml_parser.add_argument('-ptwo', dest='pathTo', type=str, required = True, help="The folder path of from 'TO' files.")
        args = xml_parser.parse_args()
        _excute(args.pathFrom, args.pathTo)
    except KeyboardInterrupt:
        sys.stderr.write("User interrupted me!\n")
        sys.exit(0)

if __name__ == '__main__':
    main()

