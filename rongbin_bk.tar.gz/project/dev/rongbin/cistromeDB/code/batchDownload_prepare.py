import os,sys
import numpy as np
import pandas as pd

# the DC table with annotation and peak file path
File = '/data5/home/rongbin/cistromeDB/newtable/2018_update/CistromeDB_allData.xls.path'

DC_mat = pd.read_csv(File, header = None, sep = '\t')
# human_Factor_data = DC_mat[(DC_mat[12] != 'hm') & (DC_mat[12] != 'ca')]
# human_Factor_data_ann = Factor_data[[0,2,5,7,8,9,11,17]]
# human_Factor_data_ann.columns = ['ID', 'Species', 'GSMID','Cell_line', 'Cell_type', 'Tissue_type', 'Factor', 'File']
# human_Factor_data_ann['File'] = [x.split('/')[-1] for x in Factor_data_ann['File']]
try:
	os.mkdir('batch_download')
except:
	pass

CA_data = DC_mat[DC_mat[12] == 'ca']
HM_data = DC_mat[DC_mat[12] == 'hm']

species = {'Homo sapiens':'human', 'Mus musculus':'mouse'}

for s in ['Homo sapiens', 'Mus musculus']:
	for f in ['factor', 'hm', 'ca']:
		saveFile = species[s]+'_'+f
		if f == 'factor':
			tmpMat = DC_mat[(DC_mat[12] != 'hm') & (DC_mat[12] != 'ca') & (DC_mat[2] == s)]
		else:
			tmpMat = DC_mat[(DC_mat[12] == f) & (DC_mat[2] == s)]
		tmpMat_ann = tmpMat[[0,2,5,7,8,9,11,17]]
		tmpMat_ann.columns = ['ID', 'Species', 'GSMID','Cell_line', 'Cell_type', 'Tissue_type', 'Factor', 'File']
		tmpMat_ann = tmpMat_ann[[str(x)!='nan' for x in tmpMat_ann['File'].tolist()]]
		tmpMat_ann['File'] = [str(x).split('/')[-1] for x in tmpMat_ann['File']]
		try:
			os.mkdir('batch_download/'+saveFile)
		except:
			pass
		tmpMat_ann.to_csv('batch_download/'+saveFile+'.txt', sep = '\t', index = None)
		out=open('batch_download/'+saveFile+'_run.sh', 'w')
		for p in tmpMat[17]:
			if str(p) == 'nan':
				continue
			cmd = 'cp %s %s'%(p, '/data5/home/rongbin/cistromeDB/newtable/2018_update/batch_download/'+saveFile+'/')
			out.write(cmd+'\n')
		out.write('tar -czf '+saveFile+'.tar.gz '+saveFile+'\n')
		out.write('tar -czf '+saveFile+'_zip.tar.gz '+saveFile+'.tar.gz '+saveFile+'.txt\n')
		out.close()


## change name
import random, string, os
import pandas as pd
record = {}
for f in [x for x in os.listdir('./') if x.endswith('_zip.tar.gz')]:
	name = ''.join(random.choices(string.ascii_uppercase + string.digits, k=20))+'.tar.gz'
	record[f]=name
	# os.system('mv %s %s'%(f, name))
record = pd.DataFrame.from_dict(record, orient = 'index')
record.to_csv('batch_download_files.csv', header = None, sep = '\t')
for f in record.index:
	name = str(record.loc[f,0])
	os.system('mv %s %s'%(f, name))




# human_ca_zip.tar.gz     R56Q7GGRZEY7L4PH4RA9.tar.gz
# human_hm_zip.tar.gz     GTYPP2KEMBOVQL3DDGS2.tar.gz
# mouse_factor_zip.tar.gz R9MXVUTB72SQ8FJLMWXU.tar.gz
# human_factor_zip.tar.gz 24KRO157XZ5Y204IEVFN.tar.gz
# mouse_ca_zip.tar.gz     FGRVH30PLYTNOQPXMCUL.tar.gz
# mouse_hm_zip.tar.gz     DPOUA6WA6SNLMRHVC7GW.tar.gz




